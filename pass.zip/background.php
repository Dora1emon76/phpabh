<?php
include("functions.php");
$chat_id = $argv[6];
$parameter = $argv[2];
$param = $argv[3];
$params = $argv[4];
$parm = $argv[5];

$counter = 0;

if($argv[1] == "fast"){
while(true){


 $user = main($chat_id);
 
    foreach ($user['otp'] as $item) {
    //sendMessage($item['id'],$chat_id,null,null);
    if (isset($item["id"]) && intval($item['id']) === intval($parameter)) {
        
        $ite = strval($item['type']);
        $otp = $item['otp'];
        }}
if($ite == strval('cancel_otp')){

   break;
    }

    if($param == 0){
    break;}
    if($counter >= 31){
    if($ite == strval('otp_taken')){

   break;
    }
file_get_contents("https://fastsms.su/stubs/handler_api.php?api_key=$fapi&action=setStatus&id=$parameter&status=8");
}
$counter++;
            $apiResponse = file_get_contents("https://fastsms.su/stubs/handler_api.php?api_key=$fapi&action=getStatus&id=$parameter");
    //sendMessage($apiResponse,$chat_id,null,null);
    if (!isset($otp) && $apiResponse == "STATUS_CANCEL" && $ite == strval('number_issued')) {
        $user = main($chat_id);
    $user['balance'] = $user['balance'] + $param;
    $spend = isset($user["spend"])?$user["spend"]:0;
    $rs = $spend > $param?floatval($spend)-floatval($param):floatval($param)-floatval($spend);
$user['spend'] = $rs;
        date_default_timezone_set('Asia/Kolkata');
    $currentDateTimeIST = new DateTime();
    $currentDateTimeIST->setTimezone(new DateTimeZone('Asia/Kolkata'));
    $cD = $currentDateTimeIST->format('d|m|Y');
    $cT = $currentDateTimeIST->format('g:i:s');
        foreach ($user['otp'] as &$item) {
    if (intval($item['id']) === intval($parameter)) {
        
        $item['type'] = 'cancel_otp';
        $item['ctime'] = $cT;
        $item['cdate'] = $cD;
        
            
            }}
            file_put_contents("data/$chat_id.json",json_encode($user));
   break;
    }
    if($apiResponse == "STATUS_WAIT_CODE"){
    sleep(10);
    continue;
}
    $otp = explode(':', $apiResponse); 
    if($otp[1] == null){
    sleep(10);
    continue;
}else{
    if($otp[0] == "STATUS_OK"){
    date_default_timezone_set('Asia/Kolkata');
    $currentDateTimeIST = new DateTime();
    $currentDateTimeIST->setTimezone(new DateTimeZone('Asia/Kolkata'));
    $currentDateIST = $currentDateTimeIST->format('d/m/Y');
    $currentTimeIST = $currentDateTimeIST->format('g:i:s');
   
    sendMessage("*Your Requested OTP is* 
*☎️ OTP : *`".$otp[1]."`
*📞 Your Number : +91* `$params`

_⚠️ Kindly Use it Before it Expire_",$chat_id,['inline_keyboard'=>[[['text'=>'📞 Next Otp','callback_data'=>"/next2 $parameter $params"],['text'=>"Buy Again",'callback_data'=>"/otp2 $parm $param 1 $currentTimeIST $currentDateIST"]]]],"markdown");
    }
    
      $a = json_decode(file_get_contents("https://fastsms.su/stubs/handler_api.php?api_key=$fapi&action=getServices"),true);
      $deposit = main($chat_id)['damo'] == null?0:main($chat_id)['damo'];
      $user = main($chat_id);
    foreach ($user['otp'] as &$item) {
    if (isset($item['id']) && intval($item['id']) === intval($parameter)) {
   $ite= $item["type"];
   $msg_id = $item["msg_id"];
    $cD = $item['Date'];
    $cT = $item['Time'];
    }}
    if($ite == "number_issued"){
    file_get_contents("https://api.telegram.org/bot$token/deleteMessage?chat_id=$chat_id&message_id=$msg_id");
    }
$msg = $ite == "otp_taken"?("🔔 Next OTP Request 🔔

🧒 User : @".$bot['callback_query']['from']['username']."
▶️ Tg Id : $chat_id
🔥 Id : $parameter
🤝 OTP : ".$otp[1]):("*🔔 New OTP Request 🔔

🧒 User :* [@".$bot['callback_query']['from']['username']."](tg://user?id=".$chat_id.")
*🔎 Telegram Id : *`$chat_id`
*🔥 Service : ".$a[$parm]."
🛒 Service Id : $parameter
🪙 Price : $param
💰 Balance :* ".main($chat_id)['balance']."
⚠️ Date : $cD
⚠️ Time : $cT
*💶 Deposit :* $deposit");
sendMessage($msg,"@$pchannel",null,"markdown");
$user = main($chat_id);
date_default_timezone_set('Asia/Kolkata');
    $currentDateTimeIST = new DateTime();
    $currentDateTimeIST->setTimezone(new DateTimeZone('Asia/Kolkata'));
    $cD = $currentDateTimeIST->format('d|m|Y');
    $cT = $currentDateTimeIST->format('g:i:s');
    foreach ($user['otp'] as &$item) {
    if (isset($item['id']) && intval($item['id']) === intval($parameter)) {
    if($item["type"] == "otp_taken"){
    $item["otp"] = $item["otp"].", ".$otp[1];
    $item['otime'] = $item["otime"].", ".$cT;
        $item['odate'] = $item["odate"].", ".$cD;
    }else{
        $item['otp'] = $otp[1];
        $item['type'] = 'otp_taken';
        $item['otime'] = $cT;
        $item['odate'] = $cD;
         }
            }
}
file_put_contents("data/$chat_id.json",json_encode($user));
file_get_contents("https://fastsms.su/stubs/handler_api.php?api_key=$fapi&action=setStatus&id=$parameter&status=3");
sleep(10);
continue;

}}}
?>