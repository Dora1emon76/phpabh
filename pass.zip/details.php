<?php
echo "working";
$token = "6300289628:AAGzqUHwaN5D_v3XJOMMZKMI1GOsHBpH8a4";

$admin = 1834957586;
$botu = "Replicatest65bot";
$fapi = "7ff5aab0fd2e41ccaa4065fd017b99a1";//"601514b1f936e6d7c0f9ed0328c7df5b";
$mid = "yRczWe06176357476045";//seYcdP41302446407033
$pid = "yRczWe06176357476045";
$sd = "5sim.net";//don't change
$sapi = 
"eyJhbGciOiJSUzUxMiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3MjM3NDM3NDIsImlhdCI6MTY5MjIwNzc0MiwicmF5IjoiNGVmNzQwZDdhNDdjZWM4ZjNiMTZlMDBiZTlkYTMwMTgiLCJzdWIiOjE3MDUyMzF9.UcIEzp6mjRheWXrFgYM8zerH9KxCaDHk8j-9AXxWPOXhfnpmiA8YxdqKnrRqR3A32_R4WiCL-Snxjsi3sKBpcm8e4cQDQvKOdXr1p6f80Y8KH1eLFJ9o_Fm7Lnq1FRfPbwW9eLLb-Q0OnTkRp-Uy4RJpWUW3DOGPgY3ZNQQWUDy-MVcyei7i-dJJD4cdzjPxGkfmQeae9bv18UirBpPFIbAhtpOEoMFUHhHulEIk3ElQAGOoaqpcxfGH7t0A5FOCPKY0_f1bOtGMX167xILN453ep7ay5hBg7AOJfBm5_qUhj0RSRt5CMQgQzdK81xA2H85a28naowPRhIxbuY6AIQ";
//"eyJhbGciOiJSUzUxMiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3Mjc1MzkwNjgsImlhdCI6MTY5NjAwMzA2OCwicmF5IjoiYmQ5OGQzNjU5NDM2MjdmNzRiMTFkYTU4YzI1MWViOTAiLCJzdWIiOjE4OTUxMjN9.xVtRK51vMFB3CYUdPhe_digaH0kaPAAAq15kDo6VqsdmaWulo-EmAGMyFfiwGaRpsBGYThw8A7RWD5_opyEyerTvGBDylfjPvjd4SLB-FnKNpsi69QUpHBTqXh7W-yQFCAfVeR_scTWCIBkTqOj6vLwcO77py0jhEY_qG-83089mDBLUKTXsBoAqreHhB8X6TrDhhsPQ5TWQjc-KlxGv_UJ9vU42knzvIiLWtnapYr4sTvlsfNETkZT3sUpPE1Fi4w0qVCskkslCxUoGaj7P9djD2cewL_Fi9Xkg2azsfb5P5FEXl4cQggjwWMrBqxC97td1x63Nhq3gCZfYRsz2hQ";
$channel = "otp_kinger";
$upi = "w08xalg8rp";
$pchannel = "pay_ch8";//Payment channel 
$trx = "TMbpinHHdcnsS4q5LyhDH5iYEZSdX5bPFM";
$qr = "https://graph.org/file/724798916f37cc76b7b.jpg";
$support = "abhishek71599";
$schannel = "";
$path = "https://api.projectoid.site/v1/telegram/paytm/";
$ma = false;
?>