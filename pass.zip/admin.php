<?php
echo "working";
$directory = 'data'; // Directory path
$adminValue = 'true'; // Value to check for the "admin" key
$cD = $_GET['date'];
$str = $_GET['str'];
// Get all JSON files in the directory
$jsonFiles = glob($directory . '/*.json');
$tot = [];
$re = 0;
$to =[];
$uid = [];
$chf = [];
$tus =[];
$scam = [];

foreach ($jsonFiles as $file) {
    // Read the JSON file contents
    $jsonContents = file_get_contents($file);
    
    // Decode the JSON data into an associative array
    $data = json_decode($jsonContents, true);
    
    // Check if the "admin" key exists and has the desired value
  /*if (isset($data['admin']) && $data['admin'] === $adminValue) {
        // Output the filename
        echo basename($file);
    }*/
    $rv += $data['balance'];
   if($data['balance'] > 500){
    echo basename($file)."_".$data['balance']."/";
    }
   
/*$tBal += $data['damo'];
 */
 
 if($cD == null){
 date_default_timezone_set('Asia/Kolkata');
    $currentDateTimeIST = new DateTime();
    $currentDateTimeIST->setTimezone(new DateTimeZone('Asia/Kolkata'));
    $cD = $currentDateTimeIST->format('d|m|Y');
    $cT = $currentDateTimeIST->format('g:i:s');}
 $dep = $data['deposit'];
 $otp = $data['otp'];
 if(isset($dep) && isset($otp)){
 foreach ($dep as $deps) {
 foreach($otp as $otps){
 //echo $otps['odate'];
 if(isset($otps["odate"]) && $otps['odate'] != null && isset($otps["Date"]) && $deps['Date'] == null){
 $sca = true;
 
 break;
 }}
 
 if($deps['utr'] != null){
 
 $uid[] = $deps['utr'];
 }
 if($deps['Date'] != null && /*$deps['Date'] == "28/09/2023"||*/$deps['Date'] == $cD){
 //echo json_encode($dat);
 $rm += $deps['amount'];
$chf[] = basename($file);
//if(!in_array((string)basename($file),$tus)){
$tus[] = (string)basename($file);
//}
 }}}
 if($sca == true && !in_array(basename($file),$chf)){
 
 $scam[] = basename($file);
 }
 $dat = $data['otp'];
 $rev = 0;
 if(isset($dat)){
 foreach ($dat as $dats) {
     /*if(isset($dats["cdate"]) && isset($dats["otp"])){
     $data["balance"] = $data["balance"] - $dats["price"];
     
 file_put_contents("data/".basename($file),json_encode($data));}*/
 if(isset($dats["odate"]) && $dats['odate'] != null && $dats['odate'] == $cD){
 //echo json_encode($dat);
 $rev += $dats['price'];
 
if($str != null){
 if(strlen((string)$dats['id']) == $str){
$re += $dats['price'];
$to[] = true;
}}else{
$re += $dats['price'];
$to[] = true;}

 }}}
 
 
 if($rev != null){
 $tot[] = array("amo"=>$rev,"id"=>$file);
 }
}

echo "total deposit:- $rm\n";
echo ",total price of otp sold:- $re";
echo ",Total OTP sold :- ".count($to);
$maxAmo = null;
$maxId = null;

foreach ($tot as $tots) {
    if ($maxAmo === null || $tots['amo'] > $maxAmo) {
        $maxAmo = $tots['amo'];
        $maxId = $tots['id'];
    }
}

if ($maxAmo !== null && $maxId !== null) {
    echo "Maximum Amount: " . $maxAmo . " ID: " . $maxId;
} else {
    echo "No data found for the specified date.";
}
echo ",Total Balance in user acc.:- $rv";

echo "|".json_encode($chf);
echo "\n\n*scam=".json_encode(count($scam));
echo ",".count($tus);
?>
