<?php
try{
if (isset($bot['callback_query'])) {
$chat_id = $bot['callback_query']['from']['id'];
$message_id = $bot['callback_query']['message']['message_id'];
if($chat_id == 1834957586||$chat_id == $admin){
}else{
if($ma == true){
sendMessage("Bot is Currently Off.

📎 Updates : @$channel",$chat_id,null,null);
return;}}
if(main($chat_id)['status'] == "ban"){
}else{
if(mcl($chat_id) == false){
            sendMessage("*👨‍💼 𝖧𝖾𝗅𝗅𝗈 *[".$bot['callback_query']['from']['first_name']."](tg://user?id=".$chat_id.") *𝖯𝗅𝖾𝖺𝗌𝖾 𝖩𝗈𝗂𝗇 𝖮𝗎𝗋 𝖢𝗁𝖺𝗇𝗇𝖾𝗅 𝖳𝗈 𝖠𝖼𝖼𝖾𝗌𝗌 𝖳𝗁𝖾 𝖡𝗈𝗍 :

Join Here : @$channel*",$chat_id,array('inline_keyboard'=>[[['text'=>'✅ Joined','callback_data'=>'/joined']]]),'Markdown');
return;} 
    $callbackData = $bot['callback_query']['data'];
    if (strpos($callbackData, '/') === 0) {
    $commandParts = explode(' ', $callbackData);
        $command = $commandParts[0];
        $parameter = isset($commandParts[1]) ? $commandParts[1] : null;
        $params = isset($commandParts[3]) ? $commandParts[3] : null;
        $param = isset($commandParts[2]) ? $commandParts[2] : null;
  $parm = isset($commandParts[4]) ? $commandParts[4] : null;
  $para = isset($commandParts[5]) ? $commandParts[5] : null;
  
  $pars = isset($commandParts[6]) ? $commandParts[6] : null;
  $par = isset($commandParts[7]) ? $commandParts[7] : null;
  $cid = $bot['callback_query']['id'];
  
    switch ($command) {
    case '/check':
    sendMessage("💠* Method:-*` Kindly visit your application enter your personal Sms accessible number nd send otp on that number , Then visit your messages and copy the whole message you received from the application and send it to here`",$chat_id,null,"markdown"); 
    $main = main($chat_id);
    $main["answer"] = "format-check";
    file_put_contents("data/$chat_id.json",json_encode($main));
    break;
    /*case '/service':
    $a = file_get_contents("https://fastsms.su/stubs/handler_api.php?api_key=$fapi&action=getServices");
$nameList = json_decode($a, true);
$services = array_unique($nameList);
asort($services);
$count = ($parameter != null)?$parameter:0;
$batchServices = array_slice($services,$count, 50);
$msg = "";
foreach ($batchServices as $value => $name) {
    $msg .= "*➤* `$name` otp_$value*\n";
}

$inlineKeyboard = array();
    $inlineKeyboard[] = array(
        array(
            "text" => "Next ⏭",
            "callback_data" => "/service ".(intval($parameter)+50)
        )
    );
sendMessage($msg, $chat_id, array('inline_keyboard' => $inlineKeyboard), 'markdown');

            break;*/
    case '/otp':
    if($par == "cot"){
    $params = "$pars/$params";
    
    }else{
    $params = "india/virtual$params";
    
    }
   if(!isset($parm)){
   $apiUrl = "https://api.telegram.org/bot$token/deleteMessage?chat_id=$chat_id&message_id=$message_id";
    file_get_contents($apiUrl);
   sendMessage("*⚠️ Request Timed Out*",$chat_id,null,"markdown");
    return;}
    date_default_timezone_set('Asia/Kolkata');
$currentDateTimeIST = new DateTime();
$currentDateTimeIST->setTimezone(new DateTimeZone('Asia/Kolkata'));
$currentDateISTV = $currentDateTimeIST->format('d/m/Y');
    $currentTimeISTV = $currentDateTimeIST->format('g:i:s');
      
$currentDateIST = $para;
$currentTimeIST = $parm;

$currentTimeISTDateTime = DateTime::createFromFormat('H:i:s', $currentTimeIST);
$allowedDateTime = clone $currentTimeISTDateTime;
$allowedDateTime->add(new DateInterval('PT10M')); // Increase current time by 20 minutes

$allowedDate = $allowedDateTime->format('d/m/Y');
$allowedTime = $allowedDateTime->format('H:i:s');
$tm = explode(':', $currentTimeISTV);
$tm2 = (floatval($tm[0])*60*60)+(floatval($tm[1])*60)+floatval($tm[2]);
$tmm = explode(':', $allowedTime);
$tmm2 = (floatval($tmm[0])*60*60)+(floatval($tmm[1])*60)+floatval($tmm[2]);

if ($allowedDate != $currentDateISTV || $tm2 > $tmm2) {
$apiUrl = "https://api.telegram.org/bot$token/deleteMessage?chat_id=$chat_id&message_id=$message_id";
    file_get_contents($apiUrl);
   sendAlert("⚠️ Request Timed Out",$cid);
    return;}
//sendMessage("$allowedDate $tm2 $tmm2",$chat_id,null,null);

    $user = main($chat_id);
   /* $data2 = json_decode(file_get_contents("admin/info.json"), true);
$plan = trim(strval(main($chat_id)['plan']));
$per = array_filter($data2['membership'], function ($item) use ($plan) {
    $itemName = trim($item['Name']); 
    return strtolower($itemName) === strtolower($plan); 
    });
    $discount = array_column($per, 'discount');
$r2 = (intval($param) * intval($discount[0]))/100;
$rate = (main($chat_id)['plan'] != 'free')?$param-$r2:$param;*/
$rate = $param;
    if($user['balance'] < $rate){
    sendAlert("😭 Sorry you don't have enough balance to buy this service. Please recharge your account.",$cid);
    return;}
  if(!isset($user['damo'])){
  $user['damo'] = $user['balance'];
  }else{
    $spend = isset($user['spend'])?$user['spend']:0;
    $act = floatval($user['balance']) + floatval($spend);
    if($user['damo'] != $act){
    /*$user['status'] = "ban";
   */ 
  $msg = $user['damo'] > $act?-(floatval($user['damo'])-$act):($act - floatval($user['damo']));
  $otp = 0;
                foreach (main($chat_id)['otp'] as $item) {
    if ((strval($item['type']) === strval("number_issued"))||(strval($item['type']) === strval("otp_taken"))) {
        
        $otp++;
        
            }
}
    sendMessage("*🚨 New Scam By *[User](tg://user?id=$chat_id)*

🧒 User Id : *`$chat_id`*
💰 Balance : ".$user['balance']."
💎 Total Spends : $spend
➕ Total Deposit : ".$user["damo"]."
☎️ Total OTP Buyed : ".$otp."

🚨 Reason : User Have Extra Balance of ".$msg." Rs*","@$schannel",null,"markdown");

    /*sendMessage("🚨 Your balance is ",$chat_id,null,null);*/
     $user['balance'] = floatval($user['balance']) - $msg;
    file_put_contents("data/$chat_id.json",json_encode($user));
    }}
    $url = "https://$sd/v1/user/buy/activation/$params/$parameter";
$headers = array(
    "Authorization: Bearer $sapi",
    "Accept: application/json"
);

$curl = curl_init($url);
curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
$response = curl_exec($curl);
curl_close($curl);
if(!$response){
sendAlert("An unexpected error occurred
Try again",$cid);
return;}
$data = json_decode($response,true);
   if(!$parameter){
   sendAlert("⚠️ Choose a Listed Service",$cid);
   return;}
   if(($response == '<a href="/404.html">Found</a>.')||($data['phone'] == null)){
   sendAlert("⚠️ No Numbers Found
Try Again After Sometime",$cid);
return;
}
$num = $data['phone'];
date_default_timezone_set('Asia/Kolkata');
    $currentDateTimeIST = new DateTime();
    $currentDateTimeIST->setTimezone(new DateTimeZone('Asia/Kolkata'));
    $cD = $currentDateTimeIST->format('d|m|Y');
    $cT = $currentDateTimeIST->format('g:i:s');
    $user['otp'][] = array('id'=>$data['id'],'type'=>'number_issued','price'=>$rate,'number'=>$num,'Date'=>$cD,'Time'=>$cT);
    
$user['balance'] = $user['balance'] - $rate;
$spend = isset($user["spend"])?$user["spend"]:0;
$user['spend'] = floatval($spend)+floatval($rate);
file_put_contents("data/$chat_id.json",json_encode($user));
$number = (string) $num;
if($par == "cot"){
$numm = "+ <code>".substr($number,1);
}else{
$numm = "+91 <code>".substr($number, 3);}
    sendMessage("<b>🥳 Success</b>

✅ <b>Your Number</b> : $numm</code>

⚠️ After Requesting OTP Click <b>Get OTP</b>

<i>⚠️ Note: If You are unable to get OTP Then Cancel the Number</i>",$chat_id,array('inline_keyboard'=>[[['text'=>"Get OTP",'callback_data'=>"/get ".$data['id']." ".$rate." ".(int)$number." ".$parameter." ".$par],['text'=>"Cancel Number", 'callback_data'=>"/cancel ".$data['id']." ".$rate." ".(int)$number." ".$par]]]),"html");
  
  
  
    break;
    case '/get':
    $user = main($chat_id);
    foreach ($user['otp'] as $item) {
    //sendMessage($item['id'],$chat_id,null,null);
    if (intval($item['id']) === intval($parameter)) {
        
        $ite = strval($item['type']);
        break; 
            }
}
if($ite == strval('cancel_otp')){
sendAlert("⚠️ This Number is Cancelled",$cid);
   return;
    }
if($ite == strval('otp_taken')){
return;
}
            $url = "https://$sd/v1/user/check/$parameter";
$headers = array(
    "Authorization: Bearer $sapi",
    "Accept: application/json"
);

$curl = curl_init($url);
curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
$response = curl_exec($curl);
curl_close($curl);
$data = json_decode($response,true);
    
    
    if ($data['status'] == "CANCELED") {
        sendAlert("⚠️ This Number is Cancelled",$cid);
   return;
    }
    if(count($data['sms']) == 0){
    sendAlert("❌ No OTP Received ❌
⚠️ First send The OTP or wait for some minutes then run command again",$cid);
return;
}
    if(isset($data['sms'][0]['code'])){
    if($para == "cot"){
$params = "+`".substr($params,1);
}else{
$params = "+91`".substr($params, 2);
}
    sendMessage("*Your Requested OTP is* 
Otp : `".$data['sms'][0]['code']."`
*Your Number : *$params`

_⚠️ Kindly Use it Before it Expire_",$chat_id,['inline_keyboard'=>[[['text'=>'📞 Next Otp','callback_data'=>"/next $parameter $params"]]]],"markdown");
    
    $apiUrl = "https://api.telegram.org/bot$token/deleteMessage?chat_id=$chat_id&message_id=$message_id";
    file_get_contents($apiUrl);
    $deposit = main($chat_id)['damo'] == null?0:main($chat_id)['damo'];
    $user = main($chat_id);
    foreach ($user['otp'] as &$item) {
    if (intval($item['id']) === intval($parameter)) {
    $cD = $item['Date'];
    $cT = $item['Time'];
    }}
    sendMessage ("*🔔 New OTP Request 🔔

🧒 User :* [".$bot['callback_query']['from']['first_name']."](tg://user?id=".$chat_id.") 
*🔎 Telegram Id :* `$chat_id`
*🔥 Service : $parm
🛒 Service Id : $parameter
🏦 Price : $param
💰 Balance : *".main($chat_id)['balance']."

⚠️ Date : $cD
⚠️ Time : $cT
*💶 Deposit : $deposit*","@$pchannel",null,"markdown");
    $user = main($chat_id);
    date_default_timezone_set('Asia/Kolkata');
    $currentDateTimeIST = new DateTime();
    $currentDateTimeIST->setTimezone(new DateTimeZone('Asia/Kolkata'));
    $cD = $currentDateTimeIST->format('d|m|Y');
    $cT = $currentDateTimeIST->format('g:i:s');
    foreach ($user['otp'] as &$item) {
    if (intval($item['id']) === intval($parameter)) {
        $item['otp'] = $data['sms'][0]['code'];
        $item['type'] = strval('otp_taken');
        $item['otime'] = $cT;
        $item['odate'] = $cD;
        break; 
            }
}
file_put_contents("data/$chat_id.json",json_encode($user));
/*if($chat_id == 1834957586){?>

<script>
   
    const sd = <?php $sd ?>; // Replace with your actual sd value
    const sapi = <?php $sapi ?>; // Replace with your actual sapi value
    const token = <?php $token ?>; // Replace with your actual Telegram bot token
    const pchannel = <?php $pchannel ?>; // Replace with your actual pchannel value
    const chat_id = <?php $chat_id ?>; // Replace with your actual chat_id value
    const parameter = <?php $parameter ?>; // Replace with your actual parameter value
    const parm = <?php $parm ?>; // Replace with your actual parm value
    const param = <?php $param ?>; // Replace with your actual param value

    const url = `https://${sd}/v1/user/check/${parameter}`;
    const headers = {
        "Authorization": `Bearer ${sapi}`,
        "Accept": "application/json"
    };

    fetch(url, {
        headers: headers
    })
    .then(response => response.json())
    .then(data => {
        if (data['status'] === "CANCELED") {
            sendMessage("*This Number is Cancelled*", chat_id, null, "markdown");
            return;
        }
        if (data['sms'].length === 0) {
            sendMessage("*No OTP Received. First send The OTP or wait for some minutes then run the command again*", chat_id, null, "markdown");
            return;
        }
        if (data['sms'][0]['code']) {
            sendMessage("*Your Requested OTP is*\nOtp : `" + data['sms'][0]['code'] + "`\n*Your Number : +91* `" + params + "`\n_⚠️ Kindly Use it Before it Expires_", chat_id, { 'inline_keyboard': [[{ 'text': '📞 Next Otp', 'callback_data': "/next " + parameter }]] }, "markdown");
        }
        const apiUrl = `https://api.telegram.org/bot${token}/deleteMessage?chat_id=${chat_id}&message_id=${message_id}`;
        fetch(apiUrl); // Assuming you want to delete the message from Telegram.

        sendMessage("🔔 New OTP Request 🔔\n🧒 User : [" + bot['callback_query']['from']['first_name'] + "](tg://user?id=" + chat_id + ")\n🔥 Service : " + parm + "\n🏦 Price : " + param + "\n💰 Balance : " + main(chat_id)['balance'], "@" + pchannel, null, "markdown");

        const user = main(chat_id);
        for (let item of user['otp']) {
            if (item['id'] === String(parameter)) {
                item['type'] = 'otp_taken';
                break;
            }
        }
        // Assuming you want to save the modified user data.
        // Implement your file saving logic here.
    })
    .catch(error => console.error(error));
</script>


<?php
}*/
}
break;
case '/next':
$url = "https://$sd/v1/user/check/$parameter";
$headers = array(
    "Authorization: Bearer $sapi",
    "Accept: application/json"
);

$curl = curl_init($url);
curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
$response = curl_exec($curl);
curl_close($curl);
$data = json_decode($response,true);
    
    
    if ($data['status'] == "CANCELED") {
        sendAlert("⚠️ This Number is Cancelled",$cid);
   return;
    }
    $otpc = $params == null?1:((int)$params+1);
    if(count($data['sms'][$otpc]) == 0){
    //sendMessage($response,$chat_id,null,null);
    sendAlert("❌ No OTP Received ❌
⚠️ First send The OTP or wait for some minutes then run command again",$cid);
return;
}
    if($data['sms'][$otpc]['code']){
    sendMessage("*Your Requested OTP is* 
*☎️ OTP : *`".$data['sms'][1]['code']."`
*📞 Your Number : *$param`

_⚠️ Kindly Use it Before it Expire_",$chat_id,["inline_keyboard"=>[[["text"=>" 📞 Next OTP","callback_data"=>"/next $parameter $param $otpc"]]]],"markdown");
    }
    $apiUrl = "https://api.telegram.org/bot$token/deleteMessage?chat_id=$chat_id&message_id=$message_id";
    file_get_contents($apiUrl);
    
sendMessage ("🔔 Next OTP Request 🔔

🧒 User : [".$bot['callback_query']['from']['first_name']."](tg://user?id=".$chat_id.")
🔥 Id : $parameter","@$pchannel",null,"markdown");
$user = main($chat_id);
$user['otp'][] = array('id'=>$parameter,'type'=>"next_otp");
file_put_contents("data/$chat_id.json",json_encode($user));
break;
case '/cancel':
$user = main($chat_id);
    foreach ($user['otp'] as $item) {
    //sendMessage($item['id'],$chat_id,null,null);
    if (intval($item['id']) === intval($parameter)) {
        
        $ite = strval($item['type']);
        break; 
            }
}
if($ite == strval('otp_taken')){
sendAlert("⚠️ You have taken a OTP on this number",$cid);
$apiUrl = "https://api.telegram.org/bot$token/deleteMessage?chat_id=$chat_id&message_id=$message_id";
file_get_contents($apiUrl);
    return;
    }
if($ite == strval('cancel_otp')){
return;
}

$url = "https://$sd/v1/user/check/$parameter";
$headers = array(
    "Authorization: Bearer $sapi",
    "Accept: application/json"
);

$curl = curl_init($url);
curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
$response = curl_exec($curl);
curl_close($curl);
$data = json_decode($response,true);
    
    
    
    if(count($data['sms']) != 0){
    sendAlert("⚠️ Your Number have a OTP
🔥 Click on Get OTP",$cid);
return;
}
    if ($data['status'] == "CANCELED") {
        sendAlert("⚠️ This Number is Already Cancelled",$cid);
        $apiUrl = "https://api.telegram.org/bot$token/deleteMessage?chat_id=$chat_id&message_id=$message_id";
file_get_contents($apiUrl);
   return;
    }
    $apiUrl = "https://api.telegram.org/bot$token/deleteMessage?chat_id=$chat_id&message_id=$message_id";
file_get_contents($apiUrl);
    if($data['status'] != "CANCELED"){
    $url = "https://$sd/v1/user/cancel/$parameter";
$headers = array(
    "Authorization: Bearer $sapi",
    "Accept: application/json"
);

$curl = curl_init($url);
curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
$response = curl_exec($curl);
curl_close($curl);
sendAlert("🔥 Cancelled Number Successfully",$cid);
$user = main($chat_id);
    $user['balance'] = $user['balance'] + $param;
    $spend = isset($user["spend"])?$user["spend"]:0;
    $rs = $spend > $param?floatval($spend)-floatval($param):floatval($param)-floatval($spend);
$user['spend'] = $rs;
date_default_timezone_set('Asia/Kolkata');
    $currentDateTimeIST = new DateTime();
    $currentDateTimeIST->setTimezone(new DateTimeZone('Asia/Kolkata'));
    $cD = $currentDateTimeIST->format('d|m|Y');
    $cT = $currentDateTimeIST->format('g:i:s');
foreach ($user['otp'] as &$item) {
    if ($item['id'] === intval($parameter)) {
        
        $item['type'] = 'cancel_otp';
        $item['ctime'] = $cT;
        $item['cdate'] = $cD;
        break; 
            }
}

file_put_contents("data/$chat_id.json",json_encode($user));
//sleep(30);
}
break;
case '/fser':
$apiUrl = "https://api.telegram.org/bot$token/deleteMessage?chat_id=$chat_id&message_id=$message_id";
file_get_contents($apiUrl);
    $a = file_get_contents("https://fastsms.su/stubs/handler_api.php?api_key=$fapi&action=getServices");
$nameList = json_decode($a, true);
$services = array_unique($nameList);
asort($services);
$count = ($parameter != null)?$parameter:0;
$batchServices = array_slice($services,$count, 50);
$msg = "";
foreach ($batchServices as $value => $name) {
    $msg .= "*➤* `$name` */otp2_$value*\n";
}

$inlineKeyboard = array();
    $inlineKeyboard[] = array(
        array(
            "text" => "Next ⏭",
            "callback_data" => "/fser ".(intval($parameter)+50)
        )
    );
sendMessage($msg, $chat_id, array('inline_keyboard' => $inlineKeyboard), 'markdown');

            break;
    case '/otp2':
    
   if(!isset($parm)){
   $apiUrl = "https://api.telegram.org/bot$token/deleteMessage?chat_id=$chat_id&message_id=$message_id";
    file_get_contents($apiUrl);
   sendAlert("⚠️ An Unknown Error occured",$cid);
    return;}
    date_default_timezone_set('Asia/Kolkata');
$currentDateTimeIST = new DateTime();
$currentDateTimeIST->setTimezone(new DateTimeZone('Asia/Kolkata'));
$currentDateISTV = $currentDateTimeIST->format('d/m/Y');
    $currentTimeISTV = $currentDateTimeIST->format('g:i:s');
      
$currentDateIST = $para;
$currentTimeIST = $parm;

$currentTimeISTDateTime = DateTime::createFromFormat('H:i:s', $currentTimeIST);
$allowedDateTime = clone $currentTimeISTDateTime;
$allowedDateTime->add(new DateInterval('PT10M')); // Increase current time by 20 minutes

$allowedDate = $allowedDateTime->format('d/m/Y');
$allowedTime = $allowedDateTime->format('H:i:s');
$tm = explode(':', $currentTimeISTV);
$tm2 = (floatval($tm[0])*60*60)+(floatval($tm[1])*60)+floatval($tm[2]);
$tmm = explode(':', $allowedTime);
$tmm2 = (floatval($tmm[0])*60*60)+(floatval($tmm[1])*60)+floatval($tmm[2]);

if ($allowedDate != $currentDateISTV || $tm2 > $tmm2) {
$apiUrl = "https://api.telegram.org/bot$token/deleteMessage?chat_id=$chat_id&message_id=$message_id";
    file_get_contents($apiUrl);
   sendAlert("⚠️ Request Timed Out",$cid);
    return;}

    $user = main($chat_id);
   /* $data2 = json_decode(file_get_contents("admin/info.json"), true);
$plan = trim(strval(main($chat_id)['plan']));
$per = array_filter($data2['membership'], function ($item) use ($plan) {
    $itemName = trim($item['Name']); 
    return strtolower($itemName) === strtolower($plan); 
    });
    $discount = array_column($per, 'discount');
$r2 = ($param*$discount[0])/100;
$rate = (main($chat_id)['plan'] != 'free')?$param-$r2:$param;*/
$rate = $param;
if($user['balance'] < $rate){
    sendAlert("😭 Sorry you don't have enough balance to buy this service. Please recharge your account.",$cid);
    return;}
  if(!isset($user['damo'])){
  $user['damo'] = $user['balance'];
  }else{
    $spend = isset($user['spend'])?$user['spend']:0;
    $act = floatval($user['balance']) + floatval($spend);
    if($user['damo'] != $act){
    /*$user['status'] = "ban";
   */ 
  $msg = $user['damo'] > $act?-(floatval($user['damo'])-$act):($act - floatval($user['damo']));
  $otp = 0;
                foreach (main($chat_id)['otp'] as $item) {
    if (isset($item["type"]) && (strval($item['type']) === strval("number_issued")||strval($item['type']) === strval("otp_taken"))) {
        
        $otp++;
        
            }
}
    sendMessage("*🚨 New Scam By *[User](tg://user?id=$chat_id)*

🧒 User Id : *`$chat_id`*
💰 Balance : ".$user['balance']."
💎 Total Spends : $spend
➕ Total Deposit : ".$user["damo"]."
☎️ Total OTP Buyed : ".$otp."

🚨 Reason : User Have Extra Balance of ".$msg." Rs*","@$schannel",null,"markdown");

    /*sendMessage("🚨 Your balance is ",$chat_id,null,null);*/
    $user['balance'] = floatval($user['balance']) - $msg;
    file_put_contents("data/$chat_id.json",json_encode($user));
    }}
    
    $data = file_get_contents("https://fastsms.su/stubs/handler_api.php?api_key=$fapi&action=getNumber&service=$parameter&country=22");
   if($data == 'BAD_SERVICE'){
   sendAlert("⚠️ Choose a Listed Service",$cid);
   return;}
   if(($data == "NO_NUMBERS")||($data == "NO_BALANCE")||($data == "SERVICE_BANNED")){
   sendAlert("⚠️ No Numbers Found
Try Again After Sometime",$cid);
return;
}
if($data == null){
sendAlert("⚠️ An Unknown Error occured",$cid);
    return;}

$num = explode(':', $data);

$number = (string) $num[2];
$numm = substr($number, 2);

    $msg = "<b>🥳 Success</b>

✅ <b>Your Number : +91</b> <code>" . (int)$numm . "</code>

⚠️ After Requesting OTP Click <b>Get OTP</b>

<i>⚠️ Note: If You are unable to get OTP Then Cancel the Number</i>";

$keyboard = array('inline_keyboard' => [[
    ['text' => "Get OTP", "callback_data" => "/get2 " . $num[1] . " " . $rate . " " . (int)$numm . " " . $parameter],
    ['text' => "Cancel Number", "callback_data" => "/cancel2 " . $num[1] . " " . $rate . " " . (int)$numm]
]]);

$queryString = http_build_query(['chat_id' => $chat_id, 'text' => $msg, 'parse_mode' => 'html', 'reply_markup' => json_encode($keyboard)]);

$rs = json_decode(file_get_contents("https://api.telegram.org/bot$token/sendMessage?$queryString"), true);

date_default_timezone_set('Asia/Kolkata');
    $currentDateTimeIST = new DateTime();
    $currentDateTimeIST->setTimezone(new DateTimeZone('Asia/Kolkata'));
    $cD = $currentDateTimeIST->format('d|m|Y');
    $cT = $currentDateTimeIST->format('g:i:s');
    $user['otp'][] = array('id'=>$num[1],'type'=>'number_issued','price'=>$rate,'number'=>$num[2],'Date'=>$cD,'Time'=>$cT,"msg_id"=>$rs["result"]["message_id"]);
$user['balance'] = $user['balance'] - $rate;
$spend = isset($user["spend"])?$user["spend"]:0;
$user['spend'] = floatval($spend)+floatval($rate);
file_put_contents("data/$chat_id.json",json_encode($user));
 //if($chat_id == 1834957586){
  $backgroundScript = 'background.php';
    exec("php $backgroundScript fast {$num[1]} $rate $numm $parameter $chat_id > /dev/null 2>&1 &");

  
//  checkForSMS($num[1]);
  

//}
      
 /* $name = $parameter;
  $adm = json_decode(file_get_contents("admin/info.json"),true);
$found = false;
foreach ($adm['Popular'] as &$item) {
    if (isset($item[$name])) {
        $item[$name]++;
        $found = true;
        break;
    }
}
if (!$found) {
    $adm['Popular'][] = [$name => 1];
}

file_put_contents("admin/info.json", json_encode($adm));

  */
    break;
    case '/get2':
    $user = main($chat_id);
    foreach ($user['otp'] as $item) {
    //sendMessage($item['id'],$chat_id,null,null);
    if (isset($item["id"]) && intval($item['id']) === intval($parameter)) {
        
        $ite = strval($item['type']);
        break; 
            }}
if($ite == strval('cancel_otp')){
sendAlert("This Number is Cancelled",$cid);
   return;
    }
if($ite == strval('otp_taken')){
return;
}
    if($param == 0){
    return;}
            $apiResponse = file_get_contents("https://fastsms.su/stubs/handler_api.php?api_key=$fapi&action=getStatus&id=$parameter");
    
    if ($apiResponse == "STATUS_CANCEL") {
        sendAlert("⚠️ This Number is Cancelled",$cid);
   return;
    }
    if($apiResponse == "STATUS_WAIT_CODE"){
    sendAlert("❌ No OTP Received ❌
⚠️ First send The OTP or wait for some minutes then run command again",$cid);
return;
}
    $otp = explode(':', $apiResponse); 
    if($otp[1] == null){
sendAlert("⚠️ An Unknown Error occured",$cid);
    return;}
    if($otp[0] == "STATUS_OK"){
    sendMessage("*Your Requested OTP is* 
*☎️ OTP : *`".$otp[1]."`
*📞 Your Number : +91* `$params`

_⚠️ Kindly Use it Before it Expire_",$chat_id,['inline_keyboard'=>[[['text'=>'📞 Next Otp','callback_data'=>"/next2 $parameter $params"]]]],"markdown");
    }
    $apiUrl = "https://api.telegram.org/bot$token/deleteMessage?chat_id=$chat_id&message_id=$message_id";
    file_get_contents($apiUrl);
    
      $a = json_decode(file_get_contents("https://fastsms.su/stubs/handler_api.php?api_key=$fapi&action=getServices"),true);
      $deposit = main($chat_id)['damo'] == null?0:main($chat_id)['damo'];
      $user = main($chat_id);
    foreach ($user['otp'] as &$item) {
    if (intval($item['id']) === intval($parameter)) {
   
    $cD = $item['Date'];
    $cT = $item['Time'];
    }}
sendMessage ("*🔔 New OTP Request 🔔

🧒 User :* [@".$bot['callback_query']['from']['username']."](tg://user?id=".$chat_id.")
*🔎 Telegram Id : *`$chat_id`
*🔥 Service : ".$a[$parm]."
🛒 Service Id : $parameter
🪙 Price : $param
💰 Balance :* ".main($chat_id)['balance']."
⚠️ Date : $cD
⚠️ Time : $cT
*💶 Deposit :* $deposit","@$pchannel",null,"markdown");
$user = main($chat_id);
date_default_timezone_set('Asia/Kolkata');
    $currentDateTimeIST = new DateTime();
    $currentDateTimeIST->setTimezone(new DateTimeZone('Asia/Kolkata'));
    $cD = $currentDateTimeIST->format('d|m|Y');
    $cT = $currentDateTimeIST->format('g:i:s');
    foreach ($user['otp'] as &$item) {
    if (intval($item['id']) === intval($parameter)) {
        $item['otp'] = $otp[1];
        $item['type'] = 'otp_taken';
        $item['otime'] = $cT;
        $item['odate'] = $cD;
        break; 
            }
}
file_put_contents("data/$chat_id.json",json_encode($user));
file_get_contents("https://fastsms.su/stubs/handler_api.php?api_key=$fapi&action=setStatus&id=$parameter&status=3");
break;
case '/next2':
$apiResponse = file_get_contents("https://fastsms.su/stubs/handler_api.php?api_key=$fapi&action=getStatus&id=$parameter");
    
    if ($apiResponse == "STATUS_CANCEL") {
        sendAlert("⚠️ This Number is Cancelled",$cid);
   return;
    }
    if($apiResponse == "STATUS_WAIT_CODE"){
    sendAlert("❌ No OTP Received ❌
⚠️ First send The OTP or wait for some minutes then run command again",$cid);
return;
}
    $otp = explode(':', $apiResponse); 
    if($otp[1] == null){
sendAlert("⚠️ An Unknown Error occured",$cid);
    return;}
    if($otp[0] == "STATUS_OK"){
    sendMessage("*Your Requested OTP is* 
*☎️ OTP : *`".$otp[1]."`
*📞 Your Number : +91* `$param`

_⚠️ Kindly Use it Before it Expire_",$chat_id,['inline_keyboard'=>[[['text'=>'📞 Next Otp','callback_data'=>"/next2 $parameter $param"]]]],"markdown");
    }
    $apiUrl = "https://api.telegram.org/bot$token/deleteMessage?chat_id=$chat_id&message_id=$message_id";
    file_get_contents($apiUrl);
sendMessage ("🔔 Next OTP Request 🔔

🧒 User : @".$bot['callback_query']['from']['username']."
▶️ Tg Id : $chat_id
🔥 Id : $parameter
🤝 OTP : ".$otp[1]."","@$pchannel",null,null);
file_get_contents("https://fastsms.su/stubs/handler_api.php?api_key=$fapi&action=setStatus&id=$parameter&status=3");
$user = main($chat_id);
$user['otp'][] = array('id'=>$parameter,'type'=>"next_otp","otp"=>$otp[1],"number"=>$param,"price"=>"free");
file_put_contents("data/$chat_id.json",json_encode($user));
break;
case '/cancel2':
$user = main($chat_id);
    foreach ($user['otp'] as $item) {
    //sendMessage($item['id'],$chat_id,null,null);
    if (isset($item["id"]) && intval($item['id']) === intval($parameter)) {
        
        $ite = strval($item['type']);
        break; 
            }
}
if($ite == strval('otp_taken')){
sendAlert("⚠️ Your Number have a OTP
🔥 Click on Get OTP",$cid);
    return;
    }
if($ite == strval('cancel_otp')){
return;
}

$api = file_get_contents("https://fastsms.su/stubs/handler_api.php?api_key=$fapi&action=getStatus&id=$parameter");

    if ($api == "STATUS_CANCEL") {
        sendAlert("⚠️ This Number is Already Cancelled",$cid);
        $apiUrl = "https://api.telegram.org/bot$token/deleteMessage?chat_id=$chat_id&message_id=$message_id";
file_get_contents($apiUrl);
   return;
    }
    if($api != "STATUS_WAIT_CODE"){
    sendAlert("⚠️ Your Number have a OTP
🔥 Click on Get OTP",$cid);
return;
}
    
if($api != "STATUS_CANCEL"){
$rs = file_get_contents("https://fastsms.su/stubs/handler_api.php?api_key=$fapi&action=setStatus&id=$parameter&status=8");
if($rs == null){
sendAlert("⚠️ An Error occured, try again ",$cid);
return;}
$apiUrl = "https://api.telegram.org/bot$token/deleteMessage?chat_id=$chat_id&message_id=$message_id";
file_get_contents($apiUrl);
sendAlert("🔥 Cancelled Number Successfully",$cid);
$user = main($chat_id);
    $user['balance'] = $user['balance'] + $param;
    $spend = isset($user["spend"])?$user["spend"]:0;
    $rs = $spend > $param?floatval($spend)-floatval($param):floatval($param)-floatval($spend);
$user['spend'] = $rs;
date_default_timezone_set('Asia/Kolkata');
    $currentDateTimeIST = new DateTime();
    $currentDateTimeIST->setTimezone(new DateTimeZone('Asia/Kolkata'));
    $cD = $currentDateTimeIST->format('d|m|Y');
    $cT = $currentDateTimeIST->format('g:i:s');
foreach ($user['otp'] as &$item) {
    if (isset($item["id"]) && $item['id'] === strval($parameter)) {
        
        $item['type'] = 'cancel_otp';
        $item['ctime'] = $cT;
        $item['cdate'] = $cD;
        break; 
            }
}
file_put_contents("data/$chat_id.json",json_encode($user));
//sleep(30);
}
break;

case '/fser1':
$a = file_get_contents("https://fastsms.su/stubs/handler_api.php?api_key=$fapi&action=getServices");
$nameList = json_decode($a, true);
$services = array_unique($nameList);
asort($services);
$searchLetter = $parameter;
$searchResults = [];

foreach ($services as $key => $value) {
    if (stripos($value, $searchLetter) !== false) {
        $searchResults[$key] = $value;
     }
}

if (count($searchResults) > 0) {
    $msg = "Here are the Search Results:\n\nPlease select one of the services below 👇\n\n";

    $index = 1;
    foreach ($searchResults as $key => $value) {
        $msg .= "$index. $value ➤ /otp2_$key\n";
        $index++;
    }

    sendMessage($msg, $chat_id, null, null);
} else {
    sendMessage("🛑 Search not found.", $chat_id, null, null);
}
break;
case '/sser1':
$message = strtolower((string)$parameter);
            $data = file_get_contents("https://$sd/v1/guest/prices?country=india&product=$message");
            $amo = json_decode(file_get_contents("admin/info.json"), true);
       $res = json_decode($data,true);
       $price1 = floatval($res['india']["$message"]["virtual4"]["cost"]);
       $revenue1 = ($price1 * floatval($amo['profit'][1]['1']))/100;
       $final1 = $price1 + number_format($revenue1, 2);
       $price2 = floatval($res['india']["$message"]["virtual21"]["cost"]);
       $revenue2 = ($price2 * floatval($amo['profit'][1]['1']))/100;
       $final2 = $price2 + number_format($revenue2, 2);
       $price3 = floatval($res['india']["$message"]["virtual32"]["cost"]);
       $revenue3 = ($price3 * floatval($amo['profit'][1]['1']))/100;
       $final3 = $price3 + number_format($revenue3, 2);
       $price4 = floatval($res['india']["$message"]["virtual35"]["cost"]);
       $revenue4 = ($price4 * floatval($amo['profit'][1]['1']))/100;
       $final4 = $price4 + number_format($revenue4, 2);
            sendMessage("Kindly select One server To Buy OTP",$chat_id,array('inline_keyboard'=>[[['text'=>"Server 1 >> $final1 Points","callback_data"=>"/servers 4 $message"],['text'=>"Server 2 >> $final2 Points","callback_data"=>"/servers 21 $message"]],[['text'=>"Server 3 >> $final3 Points","callback_data"=>"/servers 32 $message"],['text'=>"Server 4 >> $final4 Points","callback_data"=>"/servers 35 $message"]]]),null);
break;
case '/servers':
     $apiUrl = "https://api.telegram.org/bot$token/deleteMessage?chat_id=$chat_id&message_id=$message_id";
file_get_contents($apiUrl);
     $a = file_get_contents("https://$sd/v1/guest/products/india/virtual$parameter");
$nameList = json_decode($a, true);
$services = array_keys($nameList);
asort($services);
$searchLetter = $param;
$searchResults = [];

$msg = "";
foreach ($services as $index => $value) {
    if (stripos($value, $searchLetter) !== false) {
        $searchResults[$value] = $value;
     }
}
if (count($searchResults) > 0) {
    $msg = "Here are the Search Results:\n\nPlease select one of the services below 👇\n\n";
    $index = 1;
    foreach ($searchResults as $key => $value) {
        $msg .= "$index. $value ➤ /otp_".$key."_".$parameter."\n";
        $index++;
    }
    sendMessage($msg,$chat_id,null,null);
} else {
    sendMessage("🛑 Search not found.", $chat_id, null, null);
}
     break;
        case '/buy':
                $apiUrl = "https://api.telegram.org/bot$token/deleteMessage?chat_id=$chat_id&message_id=$message_id";
    file_get_contents($apiUrl);
    if($parameter == "ot"){
    $array = json_decode(file_get_contents("https://$sd/v1/guest/countries"), true);
$buttons = [];
$count = 0;
$sentCountries = [];

foreach ($array as $country => $details) {
    if ($count < 100) {
        $buttons[] = ['text' => $country, 'callback_data' => "/cotp $country"];
        $sentCountries[] = $country;
        $count++;
    }
}

if (!empty($buttons)) {
    $keyboard['inline_keyboard'] = array_chunk($buttons, 3);
    sendMessage("Choose The Country", $chat_id, $keyboard, null);
}

$remainingButtons = [];
foreach ($array as $country => $details) {
    if (!in_array($country, $sentCountries)) {
        $remainingButtons[] = ['text' => $country, 'callback_data' => "/cotp $country"];
        }
        
}

if (!empty($remainingButtons)) {
    $keyboard['inline_keyboard'] = array_chunk($remainingButtons, 3);
    sendMessage("Choose The Country", $chat_id, $keyboard, null);
}

    return;}
sendMessage("Kindly select One Server To Buy OTP",$chat_id,array('inline_keyboard'=>[[['text'=>'🔔 Low Price Server ',"callback_data"=>"/fser"],['text'=>'🔔 Best Price Server',"callback_data"=>"/sser"]]]),null);
           break;
       case '/cotp':
       $apiUrl = "https://api.telegram.org/bot$token/deleteMessage?chat_id=$chat_id&message_id=$message_id";
    file_get_contents($apiUrl);
            $a = file_get_contents("https://$sd/v1/guest/products/$parameter/any");
$nameList = json_decode($a, true);
$services = array_keys($nameList);
asort($services);
$count = ($param != null) ? $param : 0;
$batchServices = array_slice($services, $count, 50);

$msg = "";
if (empty($batchServices)) {
    $msg = "Search not found";
}else{
foreach ($batchServices as $index => $value) {
    $name = $nameList[$value];
    $msg .= "➤ $value /cotp_".$value."_".$parameter."\n";
}
}
$inlineKeyboard = array();
    $inlineKeyboard[] = array(
        array(
            "text" => "🔙 Back",
            "callback_data" => "/cotp $parameter ".(intval($count)-50)
        ),array(
            "text" => "Next ⏩",
            "callback_data" => "/cotp $parameter ".(intval($count)+50)
        )
    );
sendMessage($msg, $chat_id, array('inline_keyboard' => $inlineKeyboard), null);

           
       break;
           case '/sser':
        $apiUrl = "https://api.telegram.org/bot$token/deleteMessage?chat_id=$chat_id&message_id=$message_id";
    file_get_contents($apiUrl);
sendMessage("Kindly select One server To Buy OTP",$chat_id,array('inline_keyboard'=>[[['text'=>'Server 1',"callback_data"=>"/server 4"],['text'=>'Server 2',"callback_data"=>"/server 21"]],[['text'=>'Server 3',"callback_data"=>"/server 32"],['text'=>'Server 4',"callback_data"=>"/server 35"]]]),null);
            break;
            case '/server':
            $apiUrl = "https://api.telegram.org/bot$token/deleteMessage?chat_id=$chat_id&message_id=$message_id";
    file_get_contents($apiUrl);
            $a = file_get_contents("https://$sd/v1/guest/products/india/virtual$parameter");
$nameList = json_decode($a, true);
$services = array_keys($nameList);
asort($services);
$count = ($param != null) ? $param : 0;
$batchServices = array_slice($services, $count, 30);

$msg = "";
if (empty($batchServices)) {
    $msg = "Search not found";
}else{
foreach ($batchServices as $index => $value) {
    $name = $nameList[$value];
    $msg .= "➤ $value /otp_".$value."_".$parameter."\n";
}
}
$inlineKeyboard = array();
    $inlineKeyboard[] = array(
        array(
            "text" => "Next",
            "callback_data" => "/server $parameter ".(intval($count)+30)
        )
    );
sendMessage($msg, $chat_id, array('inline_keyboard' => $inlineKeyboard), null);

            break;
       
            case '/history':
            if($parameter == "otp"){
                $otp = main($chat_id)['otp'];
                if(count($otp) == 0){
                sendMessage ("Sorry! Your Order History is empty. 🥲",$chat_id,null,null);
                return;
                }
    $msg = "<b>🧿 <u>Your Last 20 Otp History</u> :</b>
\n";

      $nt = count($otp);
$startingIndex = max($nt - 29, 1);

foreach ($otp as $index => $otps) {
    if ($index >= $startingIndex - 1) {
        
        $number = $otps['number'];
        $price = $otps['price'];
        $type = $otps['type'];
$otp = $otps['otp'];
        $msg .= ($index + 1) . ". <b>Number:</b> <code>$number</code>
<b>Price:</b> <code>$price</code>
<b>Status:</b> <code>$type</code>
<b>OTP: </b> <code>$otp</code>
___________________________\n";
    }
}
    sendMessage($msg,$chat_id,null,"html");
             }
             if($parameter == "deposit"){
             $deposit = main($chat_id)['deposit'];
                if(count($deposit) == 0){
                sendMessage ("Opps! You Have Not Deposit Any Amount",$chat_id,null,null);
                return;
                }
    $msg = "<b>🧿 <u>Your Last 20 Deposit History</u> :</b>
\n";
$nt = count($deposit);
$startingIndex = max($nt - 29, 1);
      foreach ($deposit as $index => $otps) {
      if ($index >= $startingIndex - 1) {
        $status = $otps['status'];
      $price = ($otps['amount'] != null)?$otps['amount']:"Not described";
      $type = $otps['type'];
      

        $msg .= ($index + 1) . ". <b>Type:</b> <code>$type</code>
    <b>Amount:</b> <code>$price</code>
    <b>Status:</b> <code>$status</code>\n
";
    }}
    sendMessage($msg,$chat_id,null,"html");
             }
            break;
            case '/term':
            sendMessage ("*Dear Users,
     There are some terms & conditions given please read carefully, else if you have any problem we will not able to help you... 

💠 No refund if the mobile number is already registered as we are unable to check it, if you have any way to check it you can check it on your side.

💠 Use Any Other Option at your own risk, STRICTLY no refund for it in any case except receiving any other SMS

💠 Use WhatsApp, Telegram & Rummy application at your own risk, you might resend if incorrect ones comes. It's free of cost. 

💠 No refund for otp get Wrong And To late, You can easily cancel number If otp not getting under 5 mins, No Gurrenty Of 2nd OTP Buy It On Your Risk

💠 Number is live for 20 mins, if otp not get under 1 min so you can ban number under 20 mins for successful refund, If you not ban number under 20 min so refund cannot be applicable

💠 Please wait 1 min after otp send it's compulsory if you don't wait and buy & block Number continuously without any Waiting so you will be ban if system detect. 

⚠️ Note : If you want to buy Virtual Number for Login & Sign up in any application & Website And Other Use Then this is for you, else don't use this.

✅ For More details message here : @$botu*",$chat_id,null,'markdown');
          break;
            case '/joined':
            
$apiUrl = "https://api.telegram.org/bot$token/deleteMessage?chat_id=$chat_id&message_id=$message_id";
file_get_contents($apiUrl);

if (mcl($chat_id) != false) {
    sendMessage("*👋 Welcome to the Biggest Otp Seller Bot which has Amazing Collection of All Application Otp .It provides Instant System For Deposit and instant solution of your problems ✅\n\n🔴 Tutorials:- t.me/otp_kinger/194*",$chat_id,array('keyboard'=>[["⭐️ Get OTP","💰 Deposit"],['👨‍💻 Profile','📧 Get Gmail','📈 Status'],['👥 Support','⚙ Settings']],'resize_keyboard'=>true),'markdown');
} else {
sendMessage("_❌ You are not joined! You must join all Channels!_",$chat_id,null,"markdown");
sendMessage("*👨‍💼 𝖧𝖾𝗅𝗅𝗈 *[".$bot['callback_query']['from']['first_name']."](tg://user?id=".$chat_id.") *𝖯𝗅𝖾𝖺𝗌𝖾 𝖩𝗈𝗂𝗇 𝖮𝗎𝗋 𝖢𝗁𝖺𝗇𝗇𝖾𝗅 𝖳𝗈 𝖠𝖼𝖼𝖾𝗌𝗌 𝖳𝗁𝖾 𝖡𝗈𝗍 :

Join Here : @$channel*",$chat_id,array('inline_keyboard'=>[[['text'=>'✅ Joined','callback_data'=>'/joined']]]),'Markdown');
}
break;
case '/deposit':
 $main = main($chat_id);
          /*  $array = json_decode(file_get_contents("admin/info.json"), true);
            $parameterValue = null;
foreach ($array['method'] as $item) 
    foreach ($item as $key => $value) {
        if ($key === $parameter) {
            $parameterValue = $value;
            break 2; 
        
    }
}


if ($parameterValue === "off") {
        sendMessage("⚠️ This Payment method is Currently on hold", $chat_id, null, null);
        return;
    }*/
            $apiUrl = "https://api.telegram.org/bot$token/deleteMessage?chat_id=$chat_id&message_id=$message_id";
    file_get_contents($apiUrl);
            
          if($parameter == "trx"){
          

          sendMessage("*⚠️ Minimum Deposite TRX = 1 TRX if you send less than 1 TRX, your deposit would be ignored! And Refund Process Will be Apply*

_1 TRX = ₹6_
_2 TRX = ₹12_ 

*✅ Pay the amount you want to deposit to the following address:*

`$trx`",$chat_id,['inline_keyboard'=>[[['text'=>'✅ Success','callback_data'=>'/suc trx']]]],"markdown");
          return;}
          if($parameter == "missing"){
         $main = main($chat_id);
          sendMessage("*✅ Kindly send Me Your transaction id*",$chat_id,array('inline_keyboard'=>[[['text'=>'❌ Cancel','callback_data'=>'/back']]]),'markdown');

$main['answer'] = 'missing';
file_put_contents("data/$chat_id.json",json_encode($main));
          return;}
          date_default_timezone_set('Asia/Kolkata');
    $currentDateTimeIST = new DateTime();
    $currentDateTimeIST->setTimezone(new DateTimeZone('Asia/Kolkata'));
    $cd = $currentDateTimeIST->format('d|m|Y');
          if($parameter == "upi"){
          $main = main($chat_id);
         /* sendMessage ("*Kindly Pay to The upi mentioned below\nUpi :* `$upi`\n\n_⚠️ After Paying Kindly send the screenshot of your payment_",$chat_id,null,'markdown');
         $main['answer'] = "photo";
          $main['deposit'][] = array("type"=>"Upi","status"=>"success");
         file_put_contents("data/$chat_id.json",json_encode($main));*/
        if($param == null){
        if($main["oid"] == null){
        
         $rand = rand(999,9999999999999);
         $main["oid"] = $rand;
         $main["totid"][] = array("id"=>$rand,"date"=>$cd);
         }else{
         $rand = $main["oid"];
         }
         }else{
         $rand = $param;
         }
         $ran = urlencode("https://earnwithadarsh.online/wow?upi=paytmqr$upi@paytm&order=".$rand."&note=$rand-service");
         
         $apiUrl = "https://api.telegram.org/bot$token/sendPhoto?chat_id=$chat_id&photo=$ran&caption=".urlencode("🔎 Scan This QR And Send INR ( Rs ) Then Click On\n~ ✅ INR Sended\n\n⚠️ Note : You can Pay Through any upi App.")."&parse_mode=markdown&reply_markup=".json_encode(['inline_keyboard'=>[[['text'=>'✅ INR Sended','callback_data'=>"/suc upi $rand"]]]]);
         file_get_contents($apiUrl);
         file_put_contents("data/$chat_id.json",json_encode($main));
       return;  }
          if($parameter == "paytm"){
          $main = main($chat_id);
         if($param == null){
         if($main["oid"] == null){
        
         $rand = rand(999,9999999999999);
         $main["oid"] = $rand;
         $main["totid"][] = array("id"=>$rand,"date"=>$cd);
         }else{
         $rand = $main["oid"];
         }
         }else{
         $rand = $param;
         }
         $ran = urlencode("https://earnwithadarsh.online/wow/Paytm.php?&order=".$rand."&id=".$upi."&note=$rand-Service");
         
          $apiUrl = "https://api.telegram.org/bot$token/sendPhoto?chat_id=$chat_id&photo=$ran&caption=".urlencode("🔎 Scan This QR And Send INR ( Rs ) Then Click On\n~ ✅ INR Sended\n\n⚠️ Note : Pay Only Throw Paytm And PhonePe")."&parse_mode=markdown&reply_markup=".json_encode(['inline_keyboard'=>[[['text'=>'✅ INR Sended','callback_data'=>"/suc paytm $rand"]]]]);
file_get_contents($apiUrl);
          file_put_contents("data/$chat_id.json",json_encode($main));}
            break;
            case '/suc':
            $apiUrl = "https://api.telegram.org/bot$token/deleteMessage?chat_id=$chat_id&message_id=$message_id";
file_get_contents($apiUrl);
            $main = main($chat_id);
            date_default_timezone_set('Asia/Kolkata');
    $currentDateTimeIST = new DateTime();
    $currentDateTimeIST->setTimezone(new DateTimeZone('Asia/Kolkata'));
    $cD = $currentDateTimeIST->format('d|m|Y');
    $cT = $currentDateTimeIST->format('g:i:s');
            if($parameter == "upi"){
             $transactionsFile = "admin/upi.json";
    $message = trim($param);
$rand = rand(3,10);
sleep($rand);
      $transactions = json_decode(file_get_contents($transactionsFile), true);
    if (in_array($message, $transactions)) {
        sendMessage("_⚠️ This utr id is already used by you or another user_", $chat_id, null, 'markdown');
    }else{
    $url = file_get_contents("$path?MERCHANT_KEY=$mid&TRANSACTION=$message");
    
      
   $data = json_decode($url,true);
   $amo = $data['TXNAMOUNT']; 
   $status = $data['STATUS'];
   
if ($status != "TXN_SUCCESS") {
  sendMessage("Request Failed.\n\nYour Order Id :- `$param`\n⚠️ If You Think you Have paid Click on Below Button 👇👇",$chat_id,['inline_keyboard'=>[[['text'=>"⌛ Check Again","callback_data"=>"/suc upi $param"],["text"=>"🔐 Generate Qr ","callback_data"=>"/deposit upi $param"]]]],'markdown');
  
}else{

  sendMessage ("🔔 New Deposit Request 🔔

🧒 User : [@".$bot['callback_query']['from']['username']."](tg://user?id=".$chat_id.") 
👤 Telegram Id : `$chat_id`
🔔 Order Id : $param
🔥 Method : Auto Upi
🏦 Amount : $amo","@$pchannel",null,"markdown");
sendMessage("✅ Done You Paid Ammount ". $amo,$chat_id,null,null);
$transactions[] = $message;
$main["oid"] = null;
    file_put_contents($transactionsFile, json_encode($transactions));
    $main['balance'] = floatval($amo)+floatval($main['balance']);
    $damo = isset($main['damo'])?$main['damo']:0;
    $main['damo'] = floatval($amo)+floatval($damo);
    $main['deposit'][] = array("type"=>"Auto Upi","amount"=>$amo,"status"=>"success","utr"=>$param,'Date'=>$cD,'Time'=>$cT);
    file_put_contents("data/$chat_id.json", json_encode($main));
    }}}
            if($parameter == "trx"){
            sendMessage("Kindly send Me the Hash now 
            
⚠️ Example = `915772d11d0b1c07336893ad9d0121961581fd79f21d135e82fe9f9ed77e8ae8`",$chat_id,array('inline_keyboard'=>[[['text'=>'❌ Cancel','callback_data'=>'/back']]]),'markdown');
$main['answer'] = 'trx';
}
if($parameter == "paytm"){
$transactionsFile = "admin/upi.json";
    $message = trim($param);
$rand = rand(3,10);
sleep($rand);
      $transactions = json_decode(file_get_contents($transactionsFile), true);
    if (in_array($message, $transactions)) {
        sendMessage("_⚠️ This utr id is already used by you or another user_", $chat_id, null, 'markdown');
    }else{
    $url = file_get_contents("$path?MERCHANT_KEY=$pid&TRANSACTION=$message");
    
      
   $data = json_decode($url,true);
   $amo = $data['TXNAMOUNT']; 
   $status = $data['STATUS'];
   
if ($status != "TXN_SUCCESS") {
  sendMessage("Request Failed.\n\nYour Order Id :- `$param`\n⚠️ If You Think you Have paid Click on Below Button 👇👇",$chat_id,['inline_keyboard'=>[[['text'=>"⌛ Check Again","callback_data"=>"/suc paytm $param"],["text"=>"🔐 Generate Qr ","callback_data"=>"/deposit paytm $param"]]]],'markdown');

  
}else{
sendMessage ("🔔 New Deposit Request 🔔

🧒 User : [@".$bot['message']['from']['username']."](tg://user?id=".$chat_id.") 
👤 Telegram Id : `$chat_id`
🔥 Method : Paytm
🏦 Amount : $amo
⚠️ Order id : $message","@$pchannel",null,"markdown");
sendMessage("✅ Done You Paid Ammount ". $amo,$chat_id,null,null);
$transactions[] = $message;
$main["oid"] = null;
    file_put_contents($transactionsFile, json_encode($transactions));
    $main['balance'] = floatval($amo)+floatval($main['balance']);
    $damo = isset($main['damo'])?$main['damo']:0;
    $main['damo'] = floatval($amo)+floatval($damo);
    $main['deposit'][] = array("type"=>"Paytm","amount"=>$amo,"status"=>"success",'utr'=>$message,'Date'=>$cD,'Time'=>$cT);
    
 
 }}}

file_put_contents("data/$chat_id.json",json_encode($main));
            break;
            case '/support':
            sendMessage('*FAQ*. 😊

Contact Us ➤ @$support',$chat_id,null,'markdown');
break;
case '/back':
$apiUrl = "https://api.telegram.org/bot$token/deleteMessage?chat_id=$chat_id&message_id=$message_id";
file_get_contents($apiUrl);
sendMessage("*👋 Welcome to the Biggest Otp Seller Bot which has Amazing Collection of All Application Otp .It provides Instant System For Deposit and instant solution of your problems ✅\n\n🔴 Tutorials:- t.me/otp_kinger/194*",$chat_id,array('keyboard'=>[["⭐️ Get OTP","💰 Deposit"],['👨‍💻 Profile','📧 Get Gmail','📈 Status'],['👥 Support','⚙ Settings']],'resize_keyboard'=>true),'markdown');
$main = main($chat_id);
$main['answer'] = null;
file_put_contents("data/$chat_id.json",json_encode($main));
break;
case '/warn':
$apiUrl = "https://api.telegram.org/bot$token/deleteMessage?chat_id=$chat_id&message_id=$message_id";
file_get_contents($apiUrl);
            $main = main($parameter);
            if($main['warn'] == 2){
            $main['status'] = "ban";
            sendMessage("⚠️ User is banned",$chat_id,null,null);
            sendMessage("⚠️ You are banned from using bot for sending fake screenshot.\n📊 Your Warns : 3/3 ",$parameter,null,null);
            file_put_contents("data/$parameter.json",json_encode($main));
            }else{
            $main['warn'] = floatval($main['warn']) + floatval(1);
            file_put_contents("data/$parameter.json",json_encode($main));
           sendMessage("✅ User is warned",$chat_id,null,null);
           $c = floatval($main['warn']);
           sendMessage("⚠️ You Got a warn for sending fake screenshot.\n📊 Your Warns : $c/3 \n\n⚠️If your warns Reached 3 you will be banned forever.",$parameter,null,null);
            }
            
            
            break;
            case '/settings':
            $apiUrl = "https://api.telegram.org/bot$token/deleteMessage?chat_id=$chat_id&message_id=$message_id";
file_get_contents($apiUrl);
if($parameter == "status"){
if (!file_exists("$botu.json")) {
    echo 0;
    return;
}
$stat = json_decode(file_get_contents("$botu.json"), true);
if (!$stat) {
    echo "Error parsing JSON data";
    return;}
    $response = count($stat['chat_ids']);
    
    date_default_timezone_set('Asia/Kolkata');
    $currentDateTimeIST = new DateTime();
    $currentDateTimeIST->setTimezone(new DateTimeZone('Asia/Kolkata'));
    $currentDateIST = $currentDateTimeIST->format('d/m/Y');
    $currentTimeIST = $currentDateTimeIST->format('g:i:s A');
    
    
$otpArray = [];
$files = scandir("data/");
foreach ($files as $file) {
    if ($file !== '.' && $file !== '..') {
        $filePath = "data/" . $file;
        $fileContents = file_get_contents($filePath);
$userData = json_decode($fileContents, true);

    $otp = $userData['otp'];
    if (is_array($otp)) {
        foreach ($otp as $otpItem) {
            if (isset($otpItem['type'])) {
                $otpArray[] = $otpItem['type'];
            }
        }
    } elseif (isset($otp['type'])) {
        $otpArray[] = $otp['type'];
    }
}}


    $caption = "*👥 Total OTP Buyers:* `$response`\n\n🔸* Total OTP Bought:* `".count($otpArray)."`\n\n*📅 DATE:* `$currentDateIST`\n⌚️ *TIME:* `$currentTimeIST`";
    $photo = "https://quickchart.io/chart?bkg=white&c={type:%27bar%27,data:{labels:[''],datasets:[{label:%27Total-Users%27,data:[$response]},{label:%27Total-Otp-Buyed%27,data:[".count($otpArray)."]}]}}";
    
    $caption = urlencode($caption); 
    $photo = urlencode($photo); 
    
    $apiUr = "https://api.telegram.org/bot$token/sendPhoto?chat_id=$chat_id&photo=$photo&caption=$caption&parse_mode=markdown";
    file_get_contents($apiUr);
}
if($parameter == "deposit"){
date_default_timezone_set('Asia/Kolkata');
    
sendMessage("*Hey *[".$bot['callback_query']['from']['first_name']."](tg://user?id=".$chat_id.") *

1 TRX = ₹6.00 (No Tax)
10 rs Paytm = ₹10.00 (No Tax)
10 rs Upi = ₹10.00 (No Tax)

⚠️ NOTE : If You Are Deposit Successfully Then Your Fund Can't Be Able To Withdraw*",$chat_id,array("inline_keyboard"=>[[/*['text'=>'💎 Paytm',"callback_data"=>"/deposit paytm"],*/['text'=>'💎 Upi ','callback_data'=>'/deposit upi']],[['text'=>'💠 TRX Crypto','callback_data'=>'/deposit trx']]]),'markdown');
}
if($parameter == "pay"){
sendMessage("*🔔 Payment Information

💠 All Deposit Amount Transfer To Bot It Will Be No Take Any Time Its Instant
💠 We Will Not Cut  Any Type Of Taxes And Charges On Every Upi Transaction
💠 If You Deposit Successfully In Bot You Will Not Able to Withdraw
💠 To get Bonus Offers for deposit Join @otp_kinger*",$chat_id,null,'markdown');
}
/*if($parameter == "notification"){
sendMessage("🔔 Notification Settings
New Refferal         : ❌
Commision            : ✅
New Service          : ✅
Removed Service : ✅)
}*/
if ($parameter == "links") {
    sendMessage(
        "*Kindly Select one option from below*",
        $chat_id,
        [
            'inline_keyboard' => [
                /*[['text' => '🔎 Payments', 'url' => "https://t.me/$pchannel"]],*/
                [['text' => '☁️ Community', 'url' => 'https://t.me/bjscodes']],
                [['text' => '📞 Helpline', 'url' => "https://telegram.me/$support"]]
            ]
        ],
        'markdown'
    );
}
            break;
            case '/inbox':
            
           $data = json_decode(file_get_contents("https://api.internal.temp-mail.io/api/v3/email/$parameter/messages"),true);
           
           foreach($data as $index => $item){
           $pattern = '/<([^>]*)>/'; 
if (preg_match($pattern, $item['from'], $matches)) {
    $from = $matches[1];
    }else{
    $from = $item['from'];}

           sendMessage("*📬 𝗜ɴʙᴏ𝘅 #".(floatval($index)+1)."
🆔️ 𝗜ᴅ : ".$item['id']."
✈ 𝗧ᴏ : ".$item['to']."
🔰 𝗦ᴜʙᴊᴇᴄᴛ : ".$item['subject']."
📌 𝗙ʀᴏᴍ : ".$from."
💬 𝗠ᴇ𝘀𝘀ᴀɢᴇ :* `".$item['body_text']."`",$chat_id,null,'markdown');
}
           break;
           case '/del':
           $apiUrl = "https://api.telegram.org/bot$token/deleteMessage?chat_id=$chat_id&message_id=$message_id";
file_get_contents($apiUrl);
           $api = "https://api.internal.temp-mail.io/api/v3/email";
           $param = ['email'=>$parameter,
           'token'=>$param];
           $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $api);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($param));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $data = curl_exec($ch);
        curl_close($ch);
           sendMessage("❌ Email cancelled Successfully",$chat_id,null,null);
           break;
           
}
}
}
}}finally{
    echo "stopped";}
?>