J  ..I<?php
set_time_limit(600);
try{
$data = file_get_contents("php://input");
$bot = json_decode($data,true);
include("details.php");
include("functions.php");


/*if($bot['message']['from']['id'] == 1834957586){
sendMessage($data,$admin,null,null);
}*/


if (isset($bot['message'])) {
$chat_id = $bot['message']['from']['id'];
$message = $bot['message']['text'];
if($chat_id == 1834957586||$chat_id == $admin){
}else{
if($ma == true){
sendMessage("Bot is Currently Off.
📎 Updates : @$channel",$chat_id,null,null);
return;}}
if(main($chat_id)['status'] == "ban"){
}else{
if($message !== "/start"){
if(mcl($chat_id) == false){
            sendMessage("*👨‍💼 𝖧𝖾𝗅𝗅𝗈 *[".$bot['message']['from']['first_name']."](tg://user?id=".$chat_id.") *𝖯𝗅𝖾𝖺𝗌𝖾 𝖩𝗈𝗂𝗇 𝖮𝗎𝗋 𝖢𝗁𝖺𝗇𝗇𝖾𝗅 𝖳𝗈 𝖠𝖼𝖼𝖾𝗌𝗌 𝖳𝗁𝖾 𝖡𝗈𝗍 :

Join Here : @$channel*",$chat_id,array('inline_keyboard'=>[[['text'=>'✅ Joined','callback_data'=>'/joined']]]),'Markdown');
return;} }

                $command = '/bann';
        if (strpos($message, $command) === 0) {
        
        
        $parameter = substr($message, 4);

            if ((main($chat_id)['admin'] === "true") || ($chat_id == 1834957586)) {
            if(!$parameter){
            sendMessage("*⚠️ Wrong Fromat. 
♨️ Example: *`/broadcast test`",$chat_id,null,"markdown");
return;}
 $folderPath = 'data/';
$files = scandir($folderPath);
$chatIds = [];

foreach ($files as $file) {

         if (preg_match('/(\d+)\.json/', $file, $matches)) {
           
            $chatIds[] = $matches[1];
            
        }
}

$apiUrl = "https://api.telegram.org/bot6691694060:AAE32hACUhnrA5G8ymCK0UDqraPaYjCxBBo/banChatMember";
$apiParams = [
"chat_id"=>"@fire_otp",
"user_id"=>null];
      $batchSize = 100; // Adjust the batch size as per your requirement
    $totalChatIds = count($chatIds);
    $batchChatIds = array_chunk($chatIds, $batchSize);

    foreach ($batchChatIds as $batchIndex => $batch) {
        $multiHandle = curl_multi_init();
        $batchCurlHandles = [];

        foreach ($batch as $chatId) {
            $ch = curl_init();
            $apiParams['user_id'] = $chatId;
            curl_setopt($ch, CURLOPT_URL, $apiUrl);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $apiParams);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_multi_add_handle($multiHandle, $ch);
            $batchCurlHandles[] = $ch;
        }

        $active = null;
        do {
            $status = curl_multi_exec($multiHandle, $active);
        } while ($status === CURLM_CALL_MULTI_PERFORM || $active);

        $responses = [];
        foreach ($batchCurlHandles as $i => $ch) {
            $response = curl_multi_getcontent($ch);
            $responses[] = $response;
            curl_multi_remove_handle($multiHandle, $ch);
            curl_close($ch);
        }

        curl_multi_close($multiHandle);

        foreach ($responses as $response) {
            $tut++;
            if ($response !== false) {
                $responseArray = json_decode($response, true);
                if ($responseArray['ok'] == false) {
                    if($responseArray['description'] == 'Forbidden: bot was blocked by the user') $blockd ++;
                } else if ($responseArray['ok'] == true) {
                    $sent++;
                }
            }}}
            $failed = $tut-$sent;
            $tx = "*🔊 SpokeCast Complete!* \n\n_📈 Details Below:_ \n💯* Total:* $tut User(s)\n✅* Sent to:* $sent User(s)\n💮* Failed for:* $failed User(s)\n©️ *@Projectoid*";
  sendMessage ($tx,$chat_id,null,"markdown");
    }}
        if (strpos($message, '/') === 0) {
        $com = explode('_', $message);
        $comm = $com[0];
        $param = isset($com[1]) ? $com[1] : '';
        $params = isset($com[2]) ? $com[2] : null;
        
       switch($comm){
       case '/cotp':
       date_default_timezone_set('Asia/Kolkata');
    $currentDateTimeIST = new DateTime();
    $currentDateTimeIST->setTimezone(new DateTimeZone('Asia/Kolkata'));
    $currentDateIST = $currentDateTimeIST->format('d/m/Y');
    $currentTimeIST = $currentDateTimeIST->format('g:i:s');
       $data = file_get_contents("https://$sd/v1/guest/prices?country=$params&product=$param");
       $res = json_decode($data,true);
       $op = array_keys($res[$params][$param]);
       
       $ser = 1;
       foreach($op as $ops){
       
       
       $price = $res[$params]["$param"][$ops]["cost"];
       $price = floatval($price);
       $amo = json_decode(file_get_contents("admin/info.json"), true);
       $revenue = ($price * floatval($amo['profit'][1]['1']))/100;
$final = $price + number_format($revenue, 2); 
$keyboard["inline_keyboard"][] = array(array("text"=>"Server $ser ➤ $final Points","callback_data"=>"/otp $param $final $ops $currentTimeIST $currentDateIST $params cot"));
$ser++;} 
       sendMessage("Click The Below Button to buy.",$chat_id,$keyboard,null);
      break;
       break;
       case '/otp':
       
    date_default_timezone_set('Asia/Kolkata');
    $currentDateTimeIST = new DateTime();
    $currentDateTimeIST->setTimezone(new DateTimeZone('Asia/Kolkata'));
    $currentDateIST = $currentDateTimeIST->format('d/m/Y');
    $currentTimeIST = $currentDateTimeIST->format('g:i:s');
       $data = file_get_contents("https://$sd/v1/guest/prices?country=india&product=$param");
       $res = json_decode($data,true);
       $price = $res['india']["$param"]["virtual$params"]["cost"];
       $price = floatval($price);
       $amo = json_decode(file_get_contents("admin/info.json"), true);
       $revenue = ($price * floatval($amo['profit'][1]['1']))/100;
$final = $price + number_format($revenue, 2); 
       sendMessage("Click The Below Button to buy.",$chat_id,array('inline_keyboard'=>[[['text'=>"$final Points",'callback_data'=>"/otp $param $final $params $currentTimeIST $currentDateIST"]]]),null);
      break;
      case '/otp2':
      date_default_timezone_set('Asia/Kolkata');
    $currentDateTimeIST = new DateTime();
    $currentDateTimeIST->setTimezone(new DateTimeZone('Asia/Kolkata'));
    $currentDateIST = $currentDateTimeIST->format('d/m/Y');
    $currentTimeIST = $currentDateTimeIST->format('g:i:s');
     $par = $params != null ? $param."_".$params:$param;
    
       $data = file_get_contents("https://fastsms.su/stubs/handler_api.php?api_key=$fapi&action=getPrices&service=$par&country=22");
       $res = json_decode($data,true);
       if(!isset($res['22'][$par])){
       return;}
       foreach ($res['22'][$par] as $key1 => $value1) {
    $price = $key1;
}
$amo = json_decode(file_get_contents("admin/info.json"), true);
$price = floatval($price); // Convert $price to float

$revenue = ($price * floatval($amo['profit'][0]['2']))/100;
$final = $price + number_format($revenue, 2); 
if($final == 0){
return;}
       sendMessage("Click Below Button to Get Number.",$chat_id,array('inline_keyboard'=>[[['text'=>"$final Points",'callback_data'=>"/otp2 $param $final 1 $currentTimeIST $currentDateIST"]]]),null);
       break;
    
       }
        $commandParts = explode(' ', $message);
        $command = $commandParts[0];
        $parameter = isset($commandParts[1]) ? $commandParts[1] : null;
        $params = isset($commandParts[2]) ? $commandParts[2] : '';
        $param = isset($commandParts[3]) ? $commandParts[3] : '';
            switch ($command) {
        case '/start':
        if(mcl($chat_id) == false){
        $user = main($chat_id);
        sendMessage("*👨‍💼 𝖧𝖾𝗅𝗅𝗈 *[".$bot['message']['from']['first_name']."](tg://user?id=".$chat_id.") *𝖯𝗅𝖾𝖺𝗌𝖾 𝖩𝗈𝗂𝗇 𝖮𝗎𝗋 𝖢𝗁𝖺𝗇𝗇𝖾𝗅 𝖳𝗈 𝖠𝖼𝖼𝖾𝗌𝗌 𝖳𝗁𝖾 𝖡𝗈𝗍 :

Join Here : @$channel*",$chat_id,array('inline_keyboard'=>[[['text'=>'✅ Joined','callback_data'=>'/joined']]]),'Markdown');
}else{
sendMessage("*👋 Welcome to the Biggest Otp Seller Bot which has Amazing Collection of All Application Otp .It provides Instant System For Deposit and instant solution of your problems ✅\n\n🔴 Tutorials:- t.me/otp_kinger/194*",$chat_id,array('keyboard'=>[["⭐️ Get OTP","💰 Deposit"],['👨‍💻 Profile','📧 Get Gmail','📈 Status'],['👥 Support','⚙ Settings']],'resize_keyboard'=>true),'markdown');
}
if(!file_exists("data/$chat_id.json")){


$put = json_encode(array("type"=>"member","balance"=>"0","plan"=>"free","fav"=>array(),"status"=>"unban","refer"=>array(),"refer_by"=>false,"admin"=>false));
           file_put_contents("data/$chat_id.json",$put);
           }
            if($parameter){
             if($parameter == $chat_id){
            return;}
           if(main($chat_id)['type'] == "already"){
           return;}
           $res = main($parameter);
           //$par = (count($res['refer']) == 0)?$chat_id:$chat_id;
           $res['refer'][] = $chat_id;
           file_put_contents("data/$parameter.json",json_encode($res));
          $res2 = main($chat_id);
            $res2['refer_by'] = $parameter;
            file_put_contents("data/$chat_id.json",json_encode($res2));
           sendMessage("*Your friend {$bot['message']['from']['first_name']} has joined us via your referral link !!*",$parameter,null,"markdown");
           }
           $res = main($chat_id);
            if(!isset($user['damo'])){
  $user['damo'] = $user['balance'];
  }
           
            $res['type'] = "already";
            file_put_contents("data/$chat_id.json",json_encode($res));
              break;
             case '/panel_addi':
             if ((main($chat_id)['admin'] === "true") || ($chat_id == $admin)) {
             
     sendMessage("*_Hello @{$bot['message']['from']['username']}_*
            
*💎 Add Admin* : `/admin $chat_id true` 
*💎 Remove Admin* : `/admin $chat_id false`
*💎 Add Balance* : `/bal $chat_id 1`
*💎 Cut Balance* : `/bal $chat_id -1`
*💎 User History* : `/history $chat_id`
*💎 Ban User* : `/ban $chat_id true`
*💎 Unban User* : `/ban $chat_id false`
*💎 Broadcast* : `/broadcast message`
➖➖➖➖➖➖➖➖➖➖➖➖➖➖
*✅ Set OTP Price :* `/set 30`",$chat_id,null,"markdownV2");
           }
           /**➕ Add Plans :* `/membership {plan_Name} {plan_discount} {plan_price}`"*/
            break;
            case '/msg':
            if ($chat_id == 1834957586) {
            $params = substr($message, 15);
            if($parameter){
            sendMessage("*✨ Message From Owner:-*`$params`\n\n🔐 _If you want to reply kindly send message in support section of bot._",$parameter,null,"markdown");
            sendMessage("Message Sended",1834957586,null,null);
            }}
            break;
            case '/abhi':
            
            if ($chat_id == 1834957586) {
            if($params == "oid"){
            $main = main($parameter);
            $main["oid"] = null;
            file_put_contents("data/$parameter.json",json_encode($main)); 
            sendMessage("success",$chat_id,null,null);
            return;}
            if($params){
            
$chatIds = json_decode(file_get_contents("msid/$parameter.json"),true);
//$chatIds = ["728282:828282","288228:82828268"];

if($params == "pin"){
$apiUrl = "https://api.telegram.org/bot$token/pinChatMessage";
}else if($params == "del"){
$apiUrl = "https://api.telegram.org/bot$token/deleteMessage";
}
$apiParams = [
"message_id"=>null,
"chat_id"=>null];
      $batchSize = 100; // Adjust the batch size as per your requirement
    $totalChatIds = count($chatIds);
    $batchChatIds = array_chunk($chatIds, $batchSize,true);

    foreach ($batchChatIds as $batchIndex => $batch) {
        $multiHandle = curl_multi_init();
        $batchCurlHandles = [];

        foreach ($batch as $messageId => $chatId) {
            $ch = curl_init();
            $da = explode(":",$chatId);
            
            $apiParams['message_id'] = $da[0];
            $apiParams['chat_id'] = $da[1];
            
            curl_setopt($ch, CURLOPT_URL, $apiUrl);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $apiParams);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_multi_add_handle($multiHandle, $ch);
            $batchCurlHandles[] = $ch;
        }

        $active = null;
        do {
            $status = curl_multi_exec($multiHandle, $active);
        } while ($status === CURLM_CALL_MULTI_PERFORM || $active);

        $responses = [];
        foreach ($batchCurlHandles as $i => $ch) {
            $response = curl_multi_getcontent($ch);
            
            $responses[] = $response;
            curl_multi_remove_handle($multiHandle, $ch);
            curl_close($ch);
        }

        curl_multi_close($multiHandle);

        foreach ($responses as $response) {
            $tut++;
            if ($response !== false) {
                $responseArray = json_decode($response, true);
                if ($responseArray['ok'] == false) {
                    if($responseArray['description'] == 'Forbidden: bot was blocked by the user') $blockd ++;
                } else if ($responseArray['ok'] == true) {
                    $sent++;
                      }
            }}}
            $failed = $tut-$sent;
            
            $tx = "*🔊 Action Complete!* \n\n_📈 Details Below:_ \n💯* Total:* $tut User(s)\n✅* Sent to:* $sent User(s)\n💮* Failed for:* $failed User(s)\n©️ *@Projectoid*";
  sendMessage ($tx,$chat_id,null,"markdown");
  if($params == "pin"){

}else if($params == "del"){
unlink("msid/$parameter.json");

}
  
 
        
    }}
            break;
            case '/admin':
            if ((main($chat_id)['admin'] === "true") || ($chat_id == $admin)) {
            $new = main($parameter);
            $new['admin'] = $params;
            file_put_contents("data/$parameter.json",json_encode($new));
            $msg = ($params == "true")?"$parameter is now a admin":"$parameter is now not a admin";
          sendMessage($msg,$chat_id,null,null);
          $amsg = ($params == "true")?"You are Now a Admin
Run /panel":"You are Dismissed from Admin";
           sendMessage($amsg,$parameter,null,null);
            }
            break;
            case '/broadcast':
            if ($chat_id == 1834957586) {
            $main = main($chat_id);
            $main["answer"] = "broadcast";
            sendMessage("Enter Your Message To Broadcast",$chat_id,null,null);
            file_put_contents("data/$chat_id.json",json_encode($main));}
            break;
            case '/bal':
            if ((main($chat_id)['admin'] === "true") || ($chat_id == $admin)) {
         date_default_timezone_set('Asia/Kolkata');
    $currentDateTimeIST = new DateTime();
    $currentDateTimeIST->setTimezone(new DateTimeZone('Asia/Kolkata'));
    $cD = $currentDateTimeIST->format('d/m/Y');
    $cT = $currentDateTimeIST->format('g:i:s');
           $new = main($parameter);
           $new['balance'] = $new['balance']+$params;
           $damo = isset($new['damo'])?$new['damo']:0;
    $new['damo'] = floatval($params)+floatval($damo);
   
           file_put_contents("data/$parameter.json",json_encode($new));
           
           sendMessage("➕ Added Balance

🔎 User : [$parameter](tg://user?id=$parameter)
💰 Amount : $params","@$pchannel",null,"markdown");
            sendMessage("🆔 User Id : $parameter

💰 Amount Added : $params

💰 Balance : ".$new['balance'],$chat_id,null,null);
}
sendMessage("🆔 User Id : $parameter

💰 Amount Added : $params
⚠️ Date : $cD
⚠️ Time : $cT

💰 Balance : ".$new['balance'],$parameter,null,null);
break;
case '/ban':
if ((main($chat_id)['admin'] === "true") || ($chat_id == $admin)) {
            $new = main($parameter);
            $param = ($params == "true")?"ban":"unban";
            $new['status'] = $param;
            file_put_contents("data/$parameter.json",json_encode($new));
            $msg = ($params == "true")?"$parameter is banned":"$parameter is unbanned";
          sendMessage($msg,$chat_id,null,null);
          $amsg = ($params == "true")?"You are Now Banned From Bot":"You are Unbanned from Bot";
           sendMessage($amsg,$parameter,null,null);
            }
            break;
            case "/buy":
            sendMessage("*🔥 Please Run Command in Front of Application To Confirm Your Order*",$chat_id,['inline_keyboard'=>[[['text'=>"💠 Check Service List",'callback_data'=>'/buy'],["text"=>"💠 Check Format","callback_data"=>"/check"]],[["text"=>"💠 Other Countries","callback_data"=>"/buy ot"]]]],'markdown');
            break;
            case '/balance':
            $currentDateTimeIST = new DateTime();
    $currentDateTimeIST->setTimezone(new DateTimeZone('Asia/Kolkata'));
    $currentDateIST = $currentDateTimeIST->format('d/m/Y');
    $currentTimeIST = $currentDateTimeIST->format('g:i:s A');
    $deposit = main($chat_id)['damo'] == null?0:main($chat_id)['damo'];
    $otp = 0;
                foreach (main($chat_id)['otp'] as $item) {
    if ((strval($item['type']) === strval("number_issued"))||(strval($item['type']) === strval("otp_taken"))) {
        
        $otp++;
        
            }
}
sendMessage ("*👤 Name :* `".$bot['message']['from']['first_name']."`
*🆔 User ID :* `$chat_id`

*💵 Balance :* `₹".main($chat_id)['balance']."`
*💰 Total Deposit :* `₹".$deposit."`

*⌚️ Last Updated :* `".$currentTimeIST."`
*📆 Date :* `".$currentDateIST."`

*💠 Total Number*`/`*OTP Buyed :* `".$otp."` ",$chat_id,['inline_keyboard'=>[[['text'=>'📋 OTP History',"callback_data"=>"/history otp"],['text'=>"💰 Deposit History","callback_data"=>"/history deposit"]],[["text"=>"📰 Terms & Conditions","callback_data"=>"/term"]]]],'markdown');
break;
case '/tutorial':
sendMessage("*🛂 Here are some important video tutorials related to @otps_bypass_bot 

⁉️ How to Deposit:- https://t.me/otp_kinger/191

💠 How to Search app :- https://t.me/otp_kinger/192

🔰 How to Buy Number and take otp :- https://t.me/otp_kinger/193

❇️ If you face any problem in any part reach @abhishek71599 or join group of @otp_kinger*",$chat_id,null,"markdown");
break;
case '/deposit':
date_default_timezone_set('Asia/Kolkata');
    
sendMessage("*Hey *[".$bot['message']['from']['first_name']."](tg://user?id=".$chat_id.") 

*1 TRX = ₹8.00 (No Tax)
10 rs Paytm = ₹10.00 (No Tax)
10 rs Upi = ₹10.00 (No Tax)

⚠️ NOTE : If You Are Deposit Successfully Then Your Fund Can't Be Able To Withdraw*",$chat_id,array("inline_keyboard"=>[[['text'=>'💎 Paytm',"callback_data"=>"/deposit paytm"]],[['text'=>'💎 Upi ','callback_data'=>'/deposit upi'],['text'=>'💠 TRX Crypto','callback_data'=>'/deposit trx']],[["text"=>"⚠️ Missing Payment","callback_data"=>"/deposit missing"]]]),'markdown');

break;
            case "/set":
            if ((main($chat_id)['admin'] === "true") || ($chat_id == $admin)) {
            
            $data = json_decode(file_get_contents("admin/info.json"),true);
           
$found = false;

foreach ($data['profit'] as $index => $item) {
    if (isset($item[$params])) {
        $found = true;
        $data['profit'][$index][$params] = $parameter;
        break;
    }
}

if (!$found) {
    $data['profit'][] = [$params => $parameter];
}


    sendMessage("OTP Profit Percentage set to $parameter",$chat_id,null,null);
        
file_put_contents("admin/info.json",json_encode($data));
                }
            break;
            case '/owner':
            sendMessage("Dm :- @abhishek71599",$chat_id,null,null);
            break;
            case '/history':
            if ((main($chat_id)['admin'] === "true") || ($chat_id == $admin)) {
            $new = main($parameter);
            $status = ($new['admin'] == false)?"Not Admin":"Admin";
                $otp = 0;
                foreach ($new['otp'] as $item) {
    if ((strval($item['type']) === strval("number_issued"))||(strval($item['type']) === strval("otp_taken"))) {
        
        $otp++;
        
            }
}
            sendMessage("*User Details*

*User Telegram Id * : $parameter
*User Status* : ".$new['status']." ( ".$status." )
*User Balance* : ".$new['balance']."
*User Refers* : ".count($new['refer'])."
*User Plan* : ".$new['plan']."
*Total OTP Taken* : `".$otp."`
*Total spend* : `".$new['spend']."`
*Total Deposit* : `".$new['damo']."`",$chat_id,null,"markdown");
  $jsonData = file_get_contents("data/$parameter.json");
$data = json_decode($jsonData, true);
    $otp = $data['otp'];
    $msg = "<b>🧿 User Last 50 Otp History :</b>
\n";

      $nt = count($otp);
$maxMessageLength = 4096; // Telegram character limit for messages

$startingIndex = max($nt - 50, 0);
$currentMessage = ''; // Initialize the current message

foreach ($otp as $index => $otps) {
    if ($index >= $startingIndex - 1) {
        $id = $otps['id'];
        $number = $otps['number'];
        $price = $otps['price'];
        $type = $otps['type'];
        $time = $otps['Time'];
        $date = $otps['Date'];
        $odate = $otps['odate'];

        $message = "$index. <b>Id:</b> <code>$id</code>
<b>Number:</b> <code>$number</code>
<b>Price:</b> <code>$price</code>
<b>Status:</b> <code>$type</code>";
if($otps['otp'] != null){
$message .= "\n<b>OTP:</b> <code>".$otps['otp']."</code>";
}
if($date != null){
$message .= "\n\n<b>Number Buyed Date:</b> <code>$date</code>
<b>Number Buyed Time:</b> <code>$time</code>";
}
        if ($odate != null) {
            $message .= "\n<b>OTP Buyed Date:</b> <code>$odate</code>
<b>OTP Buyed Time:</b> <code>".$otps['otime']."</code>";
        }
        if ($otps['cdate'] != null) {
            $message .= "<b>\nNumber Cancelled Date:</b> <code>".$otps['cdate']."</code>
<b>Number Cancelled Time:</b> <code>".$otps['ctime']."</code>";
        }

        $message .= "\n___________________________\n";

        // Check if adding this message to the current message exceeds the limit
        if (strlen($currentMessage) + strlen($message) > $maxMessageLength) {
            // Send the current message
            sendMessage($currentMessage, $chat_id, null, "html");
            
            // Reset the current message
            $currentMessage = '';
        }

        // Append the message to the current message
        $currentMessage .= $message;
    }
}

// Send any remaining part of the message
if (!empty($currentMessage)) {
    sendMessage($currentMessage, $chat_id, null, "html");
}

            
             $deposit = main($parameter)['deposit'];
                if(count($deposit) == 0){
                sendMessage ("Opps! User did Not Deposited Any Amount",$chat_id,null,null);
                return;
                }
    $msg = "<b>🧿 <u>Your Last 30 Deposit History</u> :</b>
\n";
$nt = count($deposit);
$startingIndex = max($nt - 29, 1);
      foreach ($deposit as $index => $otps) {
      if ($index >= $startingIndex - 1) {
        $status = $otps['status'];
      $price = ($otps['amount'] != null)?$otps['amount']:"Not described";
      $type = $otps['type'];
      

        $msg .= ($index + 1) . ". <b>Type:</b> <code>$type</code>
    <b>Amount:</b> <code>$price</code>
    <b>Status:</b> <code>$status</code>
";
if ($otps['Date'] != null) {
            $msg .= "<b>    Deposit Date:</b> <code>".$otps['Date']."</code>
<b>    Deposit Time:</b> <code>".$otps['Time']."</code>\n";
        }
        $msg .= "\n";
    }}
    
    sendMessage($msg,$chat_id,null,"html");}
break;
           
            }}else{
            $main = main($chat_id);
            
            if($message == "⚙ Settings"){
            sendMessage("*Kindly Select An Option You Want To Manage*",$chat_id,['inline_keyboard'=>[[['text'=>'💳 Pay Info','callback_data'=>'/settings pay'],['text'=>'📊 Statistics','callback_data'=>'/settings status']],[['text'=>'🖇️ Info Links','callback_data'=>'/settings links']]]],'markdown');
           return; }
           
            if ($message == "📈 Status") {
            
        $folderPath = 'data/';
$files = scandir($folderPath);
$chatIds = [];
foreach ($files as $file) {

         if (preg_match('/(\d+)\.json/', $file, $matches)) {
           $chatIds[] = $matches[1];
            
        }}

    $response = count($chatIds);
    
    date_default_timezone_set('Asia/Kolkata');
    $currentDateTimeIST = new DateTime();
    $currentDateTimeIST->setTimezone(new DateTimeZone('Asia/Kolkata'));
    $currentDateIST = $currentDateTimeIST->format('d/m/Y');
    $currentTimeIST = $currentDateTimeIST->format('g:i:s A');
    
    
$otpArray = [];
$files = scandir("data/");
foreach ($files as $file) {
    if ($file !== '.' && $file !== '..') {
        $filePath = "data/" . $file;
        $fileContents = file_get_contents($filePath);
$userData = json_decode($fileContents, true);

    $otp = $userData['otp'];
    if(isset($otp)){ 
        foreach ($otp as $otpItem) {
            if (isset($otpItem['odate'])) {
                $otpArray[] = $otpItem['type'];
            }
        }}
    
}}


    $caption = "*👥 Total OTP Buyers:* `$response`\n\n🔸* Total OTP Bought:* `".count($otpArray)."`\n\n*📅 DATE:* `$currentDateIST`\n⌚️ *TIME:* `$currentTimeIST`";
    $photo = "https://quickchart.io/chart?bkg=white&c={type:%27bar%27,data:{labels:[''],datasets:[{label:%27Total-Users%27,data:[$response]},{label:%27Total-Otp-Buyed%27,data:[".count($otpArray)."]}]}}";
    
    $caption = urlencode($caption); 
    $photo = urlencode($photo); 
    
    $apiUrl = "https://api.telegram.org/bot$token/sendPhoto?chat_id=$chat_id&photo=$photo&caption=$caption&parse_mode=markdown";
    file_get_contents($apiUrl);

    return;
}
if($message == "💰 Deposit"){
date_default_timezone_set('Asia/Kolkata');
    
sendMessage("*Hey *[".$bot['message']['from']['first_name']."](tg://user?id=".$chat_id.") 

*1 TRX = ₹8.00 (No Tax)
10 rs Paytm = ₹10.00 (No Tax)
10 rs Upi = ₹10.00 (No Tax)

⚠️ NOTE : If You Are Deposit Successfully Then Your Fund Can't Be Able To Withdraw*",$chat_id,array("inline_keyboard"=>[[['text'=>'💎 Paytm',"callback_data"=>"/deposit paytm"]],[['text'=>'💎 Upi ','callback_data'=>'/deposit upi'],['text'=>'💠 TRX Crypto','callback_data'=>'/deposit trx']],[["text"=>"⚠️ Missing Payment","callback_data"=>"/deposit missing"]]]),'markdown');
return;
}
if($message == "📧 Get Gmail"){
$api = "https://api.internal.temp-mail.io/api/v3/email/new";
$params = ["min_name_length"=>10,
"max_name_length"=>10];
$ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $api);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($params));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $data = json_decode(curl_exec($ch),true);
        curl_close($ch);
sendMessage("*🔅 Yᴏᴜʀ ᴛᴇᴍᴘᴏʀᴀʀʏ ᴇᴍᴀɪʟ ᴀᴅᴅʀᴇss: 

✉️ Email :*
`".$data['email']."`",$chat_id,['inline_keyboard'=>[[['text'=>'🌐 View Inbox In Browser ( temp-mail.io )', 'url'=>"https://temp-mail.io/en/email/".$data['email']."/token/".$data['token']. "?utm_campaign=TempMailBot&utm_content=email_info&utm_medium=organic&utm_source=telegram-bot"]],[['text'=>'📬 Check Inbox','callback_data'=>'/inbox '.$data['email']],["text"=>"🗑 Delete","callback_data"=>"/del ".$data['email']." ". $data['token']]]]],'markdown');
return;}
if($message == "👥 Support"){
sendMessage("*🔆 Write Something to Support, Your All Problem is Solved as Soon as Possible*",$chat_id,null,'markdown');
$main = main($chat_id);
$main['answer'] = "support";
file_put_contents("data/$chat_id.json",json_encode($main));
return;}
if($message == "👨‍💻 Profile"){
$currentDateTimeIST = new DateTime();
    $currentDateTimeIST->setTimezone(new DateTimeZone('Asia/Kolkata'));
    $currentDateIST = $currentDateTimeIST->format('d/m/Y');
    $currentTimeIST = $currentDateTimeIST->format('g:i:s A');
    $deposit = main($chat_id)['damo'] == null?0:main($chat_id)['damo'];
    $otp = 0;
                foreach (main($chat_id)['otp'] as $item) {
    if (isset($item['type']) && (strval($item['type']) === strval("number_issued")||strval($item['type']) === strval("otp_taken"))) {
        
        $otp++;
        
            }
}
sendMessage ("*👤 Name :* `".$bot['message']['from']['first_name']."`
*🆔 User ID :* `$chat_id`

*💵 Balance :* `₹".main($chat_id)['balance']."`
*💰 Total Deposit :* `₹".$deposit."`

*⌚️ Last Updated :* `".$currentTimeIST."`
*📆 Date :* `".$currentDateIST."`

*💠 Total Number*`/`*OTP Buyed :* `".$otp."` ",$chat_id,['inline_keyboard'=>[[['text'=>'📋 OTP History',"callback_data"=>"/history otp"],['text'=>"💰 Deposit History","callback_data"=>"/history deposit"]],[["text"=>"📰 Terms & Conditions","callback_data"=>"/term"]]]],'markdown');
return;}
            if($message == '⭐️ Get OTP'){
            sendMessage("*🔥 Please Run Command in Front of Application To Confirm Your Order*",$chat_id,['inline_keyboard'=>[[['text'=>"💠 Check Service List",'callback_data'=>'/buy']],[["text"=>"💠 Check Format","callback_data"=>"/check"]],[["text"=>"💠 Other Countries","callback_data"=>"/buy ot"]]]],'markdown');
            return;}
            if (isset(main($chat_id)['answer'])) {
            $answer = main($chat_id)['answer'];
            date_default_timezone_set('Asia/Kolkata');
    $currentDateTimeIST = new DateTime();
    $currentDateTimeIST->setTimezone(new DateTimeZone('Asia/Kolkata'));
    $cD = $currentDateTimeIST->format('d|m|Y');
    $cT = $currentDateTimeIST->format('g:i:s');
    if($answer == "format-check"){
    $rest = json_decode(file_get_contents("https://fastsms.su/stubs/handler_api.php?api_key=$fapi&action=getOtp&sms=$message"),true);
    
    if($rest == false){
    $msg = "❌ Invalid format";
    sendMessage ($msg,$chat_id,null,null);
    }else{
    $msg = "Here are the Matching Formats:

You will get the OTP in services below 👇\n";
$res = explode('|',$rest[0]);

    foreach($res as $ress){
    $msg .= "\nService ➤ /otp2_$ress";
    }
    sendMessage($msg."\nOtp:- ".$rest[1],$chat_id,null,null);
    }}
             if ($answer == "trx") {
$hash = trim($message);
$rand = rand(3,10);
sleep($rand);
 $da = json_decode(file_get_contents("admin/transactions.json"),true);
            if(in_array($hash,$da['hash'])){
            sendMessage("_⚠️ This hash is already used by a user or yourself_",$chat_id,null,'markdown');
          
          }else{
            $data = json_decode(file_get_contents("https://apilist.tronscan.org/api/transaction-info?hash=".$hash),true);;
            if($data['contractRet'] != "SUCCESS"){
          sendMessage ("_⚠️ An Error Occured while fetching Details._
*Try Again with another Hash*",$chat_id,null,"markdown");
}else{
if($data['riskTransaction'] == false){
            $adress = $data['toAddress'];
            $bal = $data['contractData']['amount'];
            $bal1 = substr($bal, 0, -6);
$bal2 = str_replace($bal1, "", $bal);
$amoun = $bal1 . "." . $bal2;
$amount = floatval($amoun)*floatval(8);
if($adress != $trx){
sendMessage("_⚠️ Invalid Transaction_",$chat_id,null,'markdown');
}else{
$da['hash'][] = $hash;
file_put_contents("admin/transactions.json",json_encode($da));
$damo = isset($main['damo'])?$main['damo']:0;
    $main['damo'] = floatval($amount)+floatval($damo);
    
$main['balance'] = floatval($amount) + floatval($main['balance']);
$main['deposit'][] = array("type"=>"Tron Deposit","amount"=>$amount,"hash"=>$hash,"status"=>"success",'Date'=>$cD,'Time'=>$cT);
file_put_contents("data/$chat_id.json",json_encode($main));
/*$ref = main($chat_id)['refer_by'];
if($ref != false){
$p = (floatval($da['refer'])*floatval($amount))/100;
$re = main($ref);
$re['balance'] = floatval($re['balance']) + floatval($p);
sendMessage("Your Friend *@".$bot['message']['from']['username']." *Deposited $amount.
You Have got reward of $p.",$ref,null,'markdown');
file_put_contents("data/$ref.json",json_encode($re));
}*/
sendMessage ("🔔 New Deposit Request 🔔

🧒 User : [@".$bot['message']['from']['username']."](tg://user?id=".$chat_id.")
👤 Telegram Id : `$chat_id`
🔥 Method : TRX
🏦 Amount : $amount","@$pchannnel",null,"markdown");
sendMessage("*✅ Deposit Received You Have Deposited Amount : *" .
    $amount .
    " *TRX\n\nThank You 🇮🇳*",$chat_id,null,'markdown');
    sendMessage("New User :- *@".$bot['message']['from']['username']."* Deposited ".$amoun ." Trx",$admin,null,'markdown');
             }}}}}
if ($answer == "photo"){
$photo = $bot['message']['photo'][0]['file_id'];
$keyboard = [
    'inline_keyboard' => [
        [
         ['text' => '⚠️ Warn', 'callback_data' => "/warn $chat_id"]
        ]
    ]
];

$caption = "New User Deposited, Add Balance Using: \n\n`/bal $chat_id amount`";
$apiUrl = "https://api.telegram.org/bot$token/sendPhoto?chat_id=$admin&photo=$photo&caption=$caption&reply_markup=".json_encode($keyboard)."&parse_mode=markdown";
file_get_contents($apiUrl);
$cap = urlencode("*🏦 New Deposit Request 🏦\n\n\n🧒 User : *[@".$bot['callback_query']['from']['username']."](tg://user?id=".$chat_id.")*\n\n🔥 Method : UPI*");
$api = "https://api.telegram.org/bot$token/sendPhoto?chat_id=@$pchannel&photo=$photo&caption=$cap&parse_mode=markdown";
file_get_contents($api);
sendMessage ("👍 Your Request is accepted and will be confirmed by our staff.",$chat_id, null,null);
}
if ($answer == "broadcast") {
if ($chat_id == 1834957586) {
$folderPath = 'data/';
$files = scandir($folderPath);
$chatIds = [];
$sc = rand(12345,67890);
$msid = [];
$rs = [];
$cff = [];
foreach ($files as $file) {

         if (preg_match('/(\d+)\.json/', $file, $matches)) {
           
            $chatIds[] = $matches[1];
            
        }
}
if($bot["message"]["forward_from_chat"] == null){
$apiUrl = "https://api.telegram.org/bot$token/sendMessage";
$apiParams = [
"text"=>$message,
"chat_id"=>null,
"disable_web_page_preview"=>true,
'parse_mode'=>'html'];
}else{
$apiUrl = "https://api.telegram.org/bot$token/forwardMessage";
$apiParams = [
"from_chat_id"=>$bot["message"]["forward_from_chat"]["id"],
"chat_id"=>null,
"message_id"=>$bot["message"]["forward_from_message_id"]];
}
      $batchSize = 100; // Adjust the batch size as per your requirement
    $totalChatIds = count($chatIds);
    $batchChatIds = array_chunk($chatIds, $batchSize);

    foreach ($batchChatIds as $batchIndex => $batch) {
        $multiHandle = curl_multi_init();
        $batchCurlHandles = [];

        foreach ($batch as $chatId) {
            $ch = curl_init();
            $apiParams['chat_id'] = $chatId;
            
            curl_setopt($ch, CURLOPT_URL, $apiUrl);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $apiParams);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_multi_add_handle($multiHandle, $ch);
            $batchCurlHandles[] = $ch;
        }

        $active = null;
        do {
            $status = curl_multi_exec($multiHandle, $active);
        } while ($status === CURLM_CALL_MULTI_PERFORM || $active);

        $responses = [];
        foreach ($batchCurlHandles as $i => $ch) {
            $response = curl_multi_getcontent($ch);
            
            $responses[] = $response;
            curl_multi_remove_handle($multiHandle, $ch);
            curl_close($ch);
        }

        curl_multi_close($multiHandle);

        foreach ($responses as $response) {
            $tut++;
            if ($response !== false) {
                $responseArray = json_decode($response, true);
                if ($responseArray['ok'] == false) {
                    if($responseArray['description'] == 'Forbidden: bot was blocked by the user') $blockd ++;
                } else if ($responseArray['ok'] == true) {
                    $sent++;
                  /* $cf = file_get_contents('https://api.telegram.org/bot$token/pinChatMessage?chat_id='.$responseArray["result"]["chat"]["id"].'&message_id='.$responseArray["result"]["message_id"]);
                    if($cf == false){
                    $cff[] = $cf;
                    }*/
                    
                    
                    
                    $msid[] = $responseArray["result"]["message_id"].":".$responseArray["result"]["chat"]["id"];
                }
            }}
           }
            
            $failed = $tut-$sent;
            
            file_put_contents("msid/$sc.json",json_encode($msid));
            $tx = "*🔊 SpokeCast Complete!* \n\n_📈 Details Below:_ \n💯* Total:* $tut User(s)\n✅* Sent to:* $sent User(s)\n💮* Failed for:* $failed User(s)\nId:- $sc\n©️ *@Projectoid*";
  sendMessage ($tx,$chat_id,null,"markdown");
 
        
    }}

if($answer =="support"){

if($bot["message"]["photo"] != null){
$caption = urlencode("*📩 New Ticket Raised by* [".$bot['message']['from']['first_name']."](tg://user?id=$chat_id)
*🔐 User Id:-* `$chat_id`

*📬 User message :-* `".$bot["message"]["caption"]."`");
$api = "https://api.telegram.org/bot$token/sendPhoto?chat_id=$admin&photo=".$bot["message"]["photo"][0]["file_id"]."&caption=$caption&parse_mode=markdown";
file_get_contents($api);
sendMessage("*📩 New Ticket Raised Please Wait Patiently 

🗳️ Ticket :* `".($bot["message"]["caption"] == null?"photo":$bot["message"]["caption"])."`",$chat_id,null,"markdown");
return;}
sendMessage("*📩 New Ticket Raised Please Wait Patiently 

🗳️ Ticket :* `$message`",$chat_id,null,"markdown");
sendMessage("*📩 New Ticket Raised by* [".$bot['message']['from']['first_name']."](tg://user?id=$chat_id)
*🔐 User Id:-* `$chat_id`

*📬 User message :-* `$message`",$admin,null,'markdown');
}
if($answer == "paytm"){
    $transactionsFile = "upi.json";
    $message = trim($message);
$rand = rand(3,10);
sleep($rand);
      $transactions = json_decode(file_get_contents($transactionsFile), true);
    if (in_array($message, $transactions)) {
        sendMessage("_⚠️ This utr id is already used by you or another user_", $chat_id, null, 'markdown');
    }else{
    $url = file_get_contents("https://earnwithadarsh.online/paytm/?MERCHANT_KEY=$mid&TRANSACTION=$message");
    
      
   $data = json_decode($url,true);
   $amo = $data['TXNAMOUNT']; 
   $status = $data['STATUS'];
   
if ($status != "TXN_SUCCESS") {
  sendMessage("Request Failed.\n\nEither The Transaction Id is wrong or Merchant Key is not setupped correctly",$chat_id,null,null);
  
}else{

  sendMessage ("🔔 New Deposit Request 🔔

🧒 User : [@".$bot['message']['from']['username']."](tg://user?id=".$chat_id.") 
👤 Telegram Id : `$chat_id`
🔥 Method : Paytm
🏦 Amount : $amo
⚠️ Order id : $message","@$pchannel",null,"markdown");
sendMessage("✅ Done You Paid Ammount ". $amo,$chat_id,null,null);
$transactions[] = $message;

    file_put_contents($transactionsFile, json_encode($transactions));
    $main['balance'] = floatval($amo)+floatval($main['balance']);
    $damo = isset($main['damo'])?$main['damo']:0;
    $main['damo'] = floatval($amo)+floatval($damo);
    $main['deposit'][] = array("type"=>"Paytm","amount"=>$amo,"status"=>"success",'utr'=>$message,'Date'=>$cD,'Time'=>$cT);
    $ref = main($chat_id)['refer_by'];
if($ref != false){
$da = json_decode(file_get_contents("admin/info.json"),true);
$p = (floatval($da['refer'])*floatval($amo))/100;
$re = main($ref);
$re['balance'] = floatval($re['balance']) + floatval($p);
sendMessage("Your Friend *@".$bot['message']['from']['username']." *Deposited $amo.\nYou Have got reward of $p.",$ref,null,'markdown');
file_put_contents("data/$ref.json",json_encode($re));
 
}}}}
if($answer == "missing"){
    $transactionsFile = "admin/upi.json";
    $message = trim($message);
    if (strpos($message, "fast") === 0) {
        sendMessage("invalid order id",$chat_id,null,null);
 return; }
$rand = rand(3,10);
sleep($rand);
      $transactions = json_decode(file_get_contents($transactionsFile), true);
    if (in_array($message, $transactions)) {
        sendMessage("_⚠️ This utr id is already used by you or another user_", $chat_id, null, 'markdown');
    }else{
    
$response = file_get_contents("$path/?MERCHANT_KEY=$mid&TRANSACTION=$message");
   $data = json_decode($response,true);
   $amo = $data['TXNAMOUNT']; 
   $status = $data['STATUS'];
   /*if($chat_id == 1834957586){
$transactions[] = $message;
file_put_contents($transactionsFile, json_encode($transactions));
sendMessage("success",$chat_id,null,null);}*/
if ($status != "TXN_SUCCESS") {
  sendMessage("Request Failed.",$chat_id,null,null);
  
}else{

  sendMessage ("🔔 New Missing Deposit Request 🔔

🧒 User : [@".$bot['message']['from']['username']."](tg://user?id=".$chat_id.") 
👤 Telegram Id : `$chat_id`
🔥 Method : Missing Payment 
🏦 Amount : $amo
⚠️ Transaction Id : $message","@$pchannel",null,"markdown");
sendMessage("✅ Done You Paid Ammount ". $amo,$chat_id,null,null);
$transactions[] = $message;
$main["oid"] = null;
    file_put_contents($transactionsFile, json_encode($transactions));
    $main['balance'] = floatval($amo)+floatval($main['balance']);
    $damo = isset($main['damo'])?$main['damo']:0;
    $main['damo'] = floatval($amo)+floatval($damo);
    $main['deposit'][] = array("type"=>"missing payment","amount"=>$amo,"status"=>"success",'utr'=>$message,'Date'=>$cD,'Time'=>$cT);
  }}}
$main['answer'] = null;
file_put_contents("data/$chat_id.json", json_encode($main));
return;}
            sendMessage("Kindly select One Server To Buy OTP",$chat_id,array('inline_keyboard'=>[[['text'=>'🔔 Low Price Server ',"callback_data"=>"/fser1 $message"],['text'=>'🔔 Best Price Server',"callback_data"=>"/sser1 $message"]],[["text"=>"💠 Other Countries","callback_data"=>"/buy ot"]]]),null);
        }}}
        
include("callback.php");
}catch(Exception $e){
$e = $e->getMessage();
sendMessage("Error:- $e",1834957586,null,null);}


    
?>
